<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('housing_applications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('preferred_building_id')->nullable()->constrained('buildings')->nullOnDelete();
            $table->enum('preferred_room_type', ['single', 'double', 'triple', 'quad'])->nullable();
            $table->string('academic_year');
            $table->enum('semester', ['first', 'second', 'summer'])->default('first');
            $table->enum('status', ['pending', 'approved', 'rejected', 'waitlist'])->default('pending');
            $table->timestamp('application_date')->useCurrent();
            $table->timestamp('processed_at')->nullable();
            $table->foreignId('processed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('housing_applications');
    }
};
