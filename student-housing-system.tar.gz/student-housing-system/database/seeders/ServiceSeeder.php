<?php

namespace Database\Seeders;

use App\Models\Service;
use Illuminate\Database\Seeder;

class ServiceSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            [
                'name' => 'تنظيف يومي',
                'description' => 'خدمة تنظيف يومية للغرف',
                'type' => 'cleaning',
                'price' => 50,
            ],
            [
                'name' => 'تنظيف أسبوعي',
                'description' => 'خدمة تنظيف شامل أسبوعي',
                'type' => 'cleaning',
                'price' => 100,
            ],
            [
                'name' => 'صيانة عامة',
                'description' => 'خدمة صيانة عامة للغرف',
                'type' => 'maintenance',
                'price' => 0,
            ],
            [
                'name' => 'غسيل ملابس',
                'description' => 'خدمة غسيل الملابس',
                'type' => 'laundry',
                'price' => 30,
            ],
            [
                'name' => 'نقل من والى الجامعة',
                'description' => 'خدمة النقل اليومي',
                'type' => 'transport',
                'price' => 100,
            ],
        ];

        foreach ($services as $service) {
            Service::create($service);
        }
    }
}
