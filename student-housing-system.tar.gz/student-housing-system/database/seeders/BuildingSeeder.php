<?php

namespace Database\Seeders;

use App\Models\Building;
use Illuminate\Database\Seeder;

class BuildingSeeder extends Seeder
{
    public function run(): void
    {
        $buildings = [
            [
                'name' => 'مبنى الطلاب أ',
                'code' => 'BLD-A',
                'address' => 'الحرم الجامعي - المنطقة الشمالية',
                'floors_count' => 5,
                'description' => 'مبنى سكني للطلاب يتكون من 5 طوابق',
            ],
            [
                'name' => 'مبنى الطلاب ب',
                'code' => 'BLD-B',
                'address' => 'الحرم الجامعي - المنطقة الجنوبية',
                'floors_count' => 4,
                'description' => 'مبنى سكني للطلاب يتكون من 4 طوابق',
            ],
            [
                'name' => 'مبنى الطلاب ج',
                'code' => 'BLD-C',
                'address' => 'الحرم الجامعي - المنطقة الشرقية',
                'floors_count' => 6,
                'description' => 'مبنى سكني للطلاب يتكون من 6 طوابق',
            ],
        ];

        foreach ($buildings as $building) {
            Building::create($building);
        }
    }
}
