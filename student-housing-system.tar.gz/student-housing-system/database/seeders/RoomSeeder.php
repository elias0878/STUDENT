<?php

namespace Database\Seeders;

use App\Models\Building;
use App\Models\Room;
use Illuminate\Database\Seeder;

class RoomSeeder extends Seeder
{
    public function run(): void
    {
        $buildings = Building::all();
        
        $roomTypes = [
            'single' => ['capacity' => 1, 'price' => 500],
            'double' => ['capacity' => 2, 'price' => 300],
            'triple' => ['capacity' => 3, 'price' => 250],
            'quad' => ['capacity' => 4, 'price' => 200],
        ];

        $amenities = [
            'AC',
            'WiFi',
            'Desk',
            'Wardrobe',
            'Bathroom',
        ];

        foreach ($buildings as $building) {
            $roomNumber = 1;
            
            for ($floor = 1; $floor <= $building->floors_count; $floor++) {
                // Create 10 rooms per floor
                for ($i = 1; $i <= 10; $i++) {
                    $type = array_rand($roomTypes);
                    
                    Room::create([
                        'building_id' => $building->id,
                        'room_number' => $floor . sprintf('%02d', $i),
                        'floor' => $floor,
                        'type' => $type,
                        'capacity' => $roomTypes[$type]['capacity'],
                        'current_occupancy' => 0,
                        'status' => 'available',
                        'price' => $roomTypes[$type]['price'],
                        'description' => 'غرفة ' . $type . ' في الطابق ' . $floor,
                        'amenities' => array_rand(array_flip($amenities), rand(2, 5)),
                    ]);
                    
                    $roomNumber++;
                }
            }
            
            // Update building rooms count
            $building->update(['rooms_count' => $roomNumber - 1]);
        }
    }
}
