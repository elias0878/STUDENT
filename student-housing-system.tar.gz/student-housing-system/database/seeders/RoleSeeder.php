<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        // Create Roles
        $admin = Role::create(['name' => 'admin']);
        $supervisor = Role::create(['name' => 'supervisor']);
        $accountant = Role::create(['name' => 'accountant']);
        $student = Role::create(['name' => 'student']);

        // Create Permissions
        $permissions = [
            // Building permissions
            'buildings.view',
            'buildings.create',
            'buildings.edit',
            'buildings.delete',
            
            // Room permissions
            'rooms.view',
            'rooms.create',
            'rooms.edit',
            'rooms.delete',
            
            // Student permissions
            'students.view',
            'students.create',
            'students.edit',
            'students.delete',
            
            // Complaint permissions
            'complaints.view',
            'complaints.create',
            'complaints.edit',
            'complaints.delete',
            'complaints.assign',
            'complaints.resolve',
            
            // Payment permissions
            'payments.view',
            'payments.create',
            'payments.edit',
            'payments.delete',
            'payments.record',
            
            // Application permissions
            'applications.view',
            'applications.create',
            'applications.approve',
            'applications.reject',
            
            // User permissions
            'users.view',
            'users.create',
            'users.edit',
            'users.delete',
            
            // Report permissions
            'reports.view',
            'reports.export',
            'reports.import',
        ];

        foreach ($permissions as $permission) {
            Permission::create(['name' => $permission]);
        }

        // Assign permissions to roles
        $admin->givePermissionTo(Permission::all());
        
        $supervisor->givePermissionTo([
            'buildings.view',
            'rooms.view',
            'rooms.create',
            'rooms.edit',
            'students.view',
            'students.create',
            'students.edit',
            'complaints.view',
            'complaints.edit',
            'complaints.assign',
            'complaints.resolve',
            'applications.view',
            'applications.approve',
            'applications.reject',
            'reports.view',
        ]);
        
        $accountant->givePermissionTo([
            'students.view',
            'payments.view',
            'payments.create',
            'payments.edit',
            'payments.record',
            'reports.view',
            'reports.export',
        ]);
        
        $student->givePermissionTo([
            'complaints.create',
            'applications.create',
        ]);
    }
}
