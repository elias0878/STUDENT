<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Create Admin
        $admin = User::create([
            'name' => 'مدير النظام',
            'email' => 'admin@housing.com',
            'password' => Hash::make('password'),
            'phone' => '0500000000',
            'is_active' => true,
        ]);
        $admin->assignRole('admin');

        // Create Supervisor
        $supervisor = User::create([
            'name' => 'مشرف السكن',
            'email' => 'supervisor@housing.com',
            'password' => Hash::make('password'),
            'phone' => '0500000001',
            'is_active' => true,
        ]);
        $supervisor->assignRole('supervisor');

        // Create Accountant
        $accountant = User::create([
            'name' => 'المحاسب',
            'email' => 'accountant@housing.com',
            'password' => Hash::make('password'),
            'phone' => '0500000002',
            'is_active' => true,
        ]);
        $accountant->assignRole('accountant');

        // Create Sample Students
        $students = [
            [
                'name' => 'أحمد محمد',
                'email' => 'ahmed@student.com',
                'student_id' => 'STU001',
                'phone' => '0500000003',
            ],
            [
                'name' => 'محمد علي',
                'email' => 'mohamed@student.com',
                'student_id' => 'STU002',
                'phone' => '0500000004',
            ],
            [
                'name' => 'خالد عبدالله',
                'email' => 'khaled@student.com',
                'student_id' => 'STU003',
                'phone' => '0500000005',
            ],
            [
                'name' => 'سعيد Ibrahim',
                'email' => 'saeed@student.com',
                'student_id' => 'STU004',
                'phone' => '0500000006',
            ],
            [
                'name' => 'عمر حسن',
                'email' => 'omar@student.com',
                'student_id' => 'STU005',
                'phone' => '0500000007',
            ],
        ];

        foreach ($students as $studentData) {
            $student = User::create([
                'name' => $studentData['name'],
                'email' => $studentData['email'],
                'password' => Hash::make('password'),
                'phone' => $studentData['phone'],
                'student_id' => $studentData['student_id'],
                'is_active' => true,
            ]);
            $student->assignRole('student');
        }
    }
}
