<?php

namespace Database\Seeders;

use App\Models\InternetBubble;
use Illuminate\Database\Seeder;

class InternetBubbleSeeder extends Seeder
{
    public function run(): void
    {
        $bubbles = [
            [
                'name' => 'باقة 10 ميجا',
                'code' => 'NET-10',
                'speed' => 10,
                'data_limit' => 100,
                'duration_days' => 30,
                'price' => 50,
                'description' => 'باقة إنترنت 10 ميجا مع 100 جيجا بيانات',
            ],
            [
                'name' => 'باقة 20 ميجا',
                'code' => 'NET-20',
                'speed' => 20,
                'data_limit' => 200,
                'duration_days' => 30,
                'price' => 80,
                'description' => 'باقة إنترنت 20 ميجا مع 200 جيجا بيانات',
            ],
            [
                'name' => 'باقة 50 ميجا',
                'code' => 'NET-50',
                'speed' => 50,
                'data_limit' => 500,
                'duration_days' => 30,
                'price' => 150,
                'description' => 'باقة إنترنت 50 ميجا مع 500 جيجا بيانات',
            ],
            [
                'name' => 'باقة 100 ميجا',
                'code' => 'NET-100',
                'speed' => 100,
                'data_limit' => null,
                'duration_days' => 30,
                'price' => 250,
                'description' => 'باقة إنترنت 100 ميجا غير محدودة',
            ],
        ];

        foreach ($bubbles as $bubble) {
            InternetBubble::create($bubble);
        }
    }
}
