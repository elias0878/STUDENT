<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ComplaintController as ApiComplaintController;
use App\Http\Controllers\Api\PaymentController as ApiPaymentController;
use App\Http\Controllers\Api\RoomController as ApiRoomController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Public Routes
Route::post('/login', [AuthController::class, 'login']);

// Protected Routes
Route::middleware(['auth:sanctum'])->group(function () {
    
    // User
    Route::get('/user', [AuthController::class, 'user']);
    Route::patch('/user', [AuthController::class, 'updateProfile']);
    Route::post('/logout', [AuthController::class, 'logout']);
    
    // Rooms
    Route::get('/rooms', [ApiRoomController::class, 'index']);
    Route::get('/rooms/available', [ApiRoomController::class, 'available']);
    Route::get('/rooms/{room}', [ApiRoomController::class, 'show']);
    Route::get('/my-room', [ApiRoomController::class, 'myRoom']);
    
    // Complaints (Student Only)
    Route::middleware(['role:student'])->group(function () {
        Route::get('/complaints', [ApiComplaintController::class, 'index']);
        Route::post('/complaints', [ApiComplaintController::class, 'store']);
        Route::get('/complaints/{complaint}', [ApiComplaintController::class, 'show']);
    });
    
    // Payments (Student Only)
    Route::middleware(['role:student'])->group(function () {
        Route::get('/payments', [ApiPaymentController::class, 'index']);
        Route::get('/payments/{payment}', [ApiPaymentController::class, 'show']);
        Route::get('/payments/pending/list', [ApiPaymentController::class, 'pending']);
        Route::get('/payments/history/list', [ApiPaymentController::class, 'history']);
    });
});
