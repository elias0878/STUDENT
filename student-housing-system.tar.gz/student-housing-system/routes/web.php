<?php

use App\Http\Controllers\BuildingController;
use App\Http\Controllers\ComplaintController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ExcelController;
use App\Http\Controllers\HousingApplicationController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RoomController;
use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return redirect()->route('login');
});

// Authentication Routes (Laravel Breeze)
require __DIR__.'/auth.php';

// Protected Routes
Route::middleware(['auth'])->group(function () {
    
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Profile Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Admin Only Routes
    Route::middleware(['role:admin'])->group(function () {
        // Buildings
        Route::resource('buildings', BuildingController::class);
        
        // Excel Import/Export
        Route::get('/excel/import', [ExcelController::class, 'showImportForm'])->name('excel.import');
        Route::post('/excel/import/students', [ExcelController::class, 'importStudents'])->name('excel.import.students');
        Route::post('/excel/import/rooms', [ExcelController::class, 'importRooms'])->name('excel.import.rooms');
        
        Route::get('/excel/export', [ExcelController::class, 'showExportForm'])->name('excel.export');
        Route::get('/excel/export/residents', [ExcelController::class, 'exportResidents'])->name('excel.export.residents');
        Route::get('/excel/export/payments', [ExcelController::class, 'exportPayments'])->name('excel.export.payments');
        Route::get('/excel/export/rooms', [ExcelController::class, 'exportAvailableRooms'])->name('excel.export.rooms');
    });
    
    // Admin & Supervisor Routes
    Route::middleware(['role:admin|supervisor'])->group(function () {
        // Rooms
        Route::resource('rooms', RoomController::class);
        Route::get('/rooms/available/list', [RoomController::class, 'availableRooms'])->name('rooms.available');
        
        // Students
        Route::resource('students', StudentController::class);
        Route::post('/students/{student}/assign-room', [StudentController::class, 'assignRoom'])->name('students.assign-room');
        
        // Complaints Management
        Route::post('/complaints/{complaint}/assign', [ComplaintController::class, 'assign'])->name('complaints.assign');
        Route::post('/complaints/{complaint}/resolve', [ComplaintController::class, 'resolve'])->name('complaints.resolve');
    });
    
    // Complaints (All authenticated users)
    Route::resource('complaints', ComplaintController::class);
    Route::get('/my-complaints', [ComplaintController::class, 'myComplaints'])->name('complaints.my');
    
    // Admin & Accountant Routes
    Route::middleware(['role:admin|accountant'])->group(function () {
        // Payments
        Route::resource('payments', PaymentController::class);
        Route::post('/payments/{payment}/record', [PaymentController::class, 'recordPayment'])->name('payments.record');
        Route::get('/overdue-payments', [PaymentController::class, 'overdue'])->name('payments.overdue');
    });
    
    // My Payments (Students)
    Route::get('/my-payments', [PaymentController::class, 'myPayments'])->name('payments.my');
    
    // Housing Applications
    Route::resource('applications', HousingApplicationController::class)->except(['edit', 'update']);
    Route::get('/my-applications', [HousingApplicationController::class, 'myApplications'])->name('applications.my');
    
    // Admin & Supervisor Application Management
    Route::middleware(['role:admin|supervisor'])->group(function () {
        Route::post('/applications/{application}/approve', [HousingApplicationController::class, 'approve'])->name('applications.approve');
        Route::post('/applications/{application}/reject', [HousingApplicationController::class, 'reject'])->name('applications.reject');
    });
});

// Test Route
Route::get('/test', function () {
    return 'Student Housing System is working!';
});
