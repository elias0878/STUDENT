@extends('layouts.app')

@section('title', 'الغرف')
@section('page_title', 'إدارة الغرف')

@section('content')
<div class="space-y-6">
    <!-- Header & Filters -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white">قائمة الغرف</h2>
            @hasanyrole('admin|supervisor')
            <a href="{{ route('rooms.create') }}" class="mt-4 md:mt-0 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center">
                <i class="fas fa-plus ml-2"></i>
                إضافة غرفة جديدة
            </a>
            @endhasanyrole
        </div>
        
        <!-- Filters -->
        <form action="{{ route('rooms.index') }}" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">المبنى</label>
                <select name="building" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الكل</option>
                    @foreach($buildings as $building)
                        <option value="{{ $building->id }}" {{ request('building') == $building->id ? 'selected' : '' }}>{{ $building->name }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">الطابق</label>
                <input type="number" name="floor" value="{{ request('floor') }}" min="1"
                    class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">النوع</label>
                <select name="type" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الكل</option>
                    <option value="single" {{ request('type') == 'single' ? 'selected' : '' }}>فردية</option>
                    <option value="double" {{ request('type') == 'double' ? 'selected' : '' }}>زوجية</option>
                    <option value="triple" {{ request('type') == 'triple' ? 'selected' : '' }}>ثلاثية</option>
                    <option value="quad" {{ request('type') == 'quad' ? 'selected' : '' }}>رباعية</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">الحالة</label>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الكل</option>
                    <option value="available" {{ request('status') == 'available' ? 'selected' : '' }}>متاحة</option>
                    <option value="occupied" {{ request('status') == 'occupied' ? 'selected' : '' }}>مشغولة</option>
                    <option value="maintenance" {{ request('status') == 'maintenance' ? 'selected' : '' }}>تحت الصيانة</option>
                </select>
            </div>
            <div class="md:col-span-4 flex justify-end">
                <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg">
                    <i class="fas fa-filter ml-2"></i>
                    تصفية
                </button>
            </div>
        </form>
    </div>
    
    <!-- Rooms Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        @forelse($rooms as $room)
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden card-hover">
                <div class="h-24 bg-gradient-to-r {{ $room->status === 'available' ? 'from-green-500 to-green-700' : ($room->status === 'occupied' ? 'from-red-500 to-red-700' : 'from-yellow-500 to-yellow-700') }} flex items-center justify-center">
                    <i class="fas fa-door-open text-4xl text-white opacity-50"></i>
                </div>
                <div class="p-4">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h3 class="text-lg font-bold text-gray-800 dark:text-white">{{ $room->room_number }}</h3>
                            <p class="text-sm text-gray-500">{{ $room->building->name ?? 'N/A' }}</p>
                        </div>
                        <span class="px-2 py-1 text-xs rounded-full {{ $room->status === 'available' ? 'bg-green-100 text-green-800' : ($room->status === 'occupied' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800') }}">
                            {{ $room->status === 'available' ? 'متاحة' : ($room->status === 'occupied' ? 'مشغولة' : 'صيانة') }}
                        </span>
                    </div>
                    
                    <div class="space-y-1 mb-4">
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">الطابق:</span>
                            <span class="text-gray-800 dark:text-white">{{ $room->floor }}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">النوع:</span>
                            <span class="text-gray-800 dark:text-white">{{ $room->type }}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">السعة:</span>
                            <span class="text-gray-800 dark:text-white">{{ $room->current_occupancy }}/{{ $room->capacity }}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">السعر:</span>
                            <span class="text-primary-600 font-medium">${{ number_format($room->price, 2) }}</span>
                        </div>
                    </div>
                    
                    <div class="flex space-x-2 space-x-reverse">
                        <a href="{{ route('rooms.show', $room) }}" class="flex-1 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 py-2 rounded-lg text-center text-sm">
                            <i class="fas fa-eye ml-1"></i> عرض
                        </a>
                        @hasanyrole('admin|supervisor')
                        <a href="{{ route('rooms.edit', $room) }}" class="flex-1 bg-primary-100 dark:bg-primary-900 hover:bg-primary-200 dark:hover:bg-primary-800 text-primary-700 dark:text-primary-300 py-2 rounded-lg text-center text-sm">
                            <i class="fas fa-edit ml-1"></i> تعديل
                        </a>
                        @endhasanyrole
                    </div>
                </div>
            </div>
        @empty
            <div class="col-span-full text-center py-12">
                <i class="fas fa-door-open text-6xl text-gray-300 mb-4"></i>
                <p class="text-gray-500">لا توجد غرف مطابقة للبحث</p>
            </div>
        @endforelse
    </div>
    
    <!-- Pagination -->
    <div class="mt-6">
        {{ $rooms->links() }}
    </div>
</div>
@endsection
