@extends('layouts.app')

@section('title', 'إضافة غرفة')
@section('page_title', 'إضافة غرفة جديدة')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <form action="{{ route('rooms.store') }}" method="POST">
            @csrf
            
            <div class="space-y-6">
                <!-- Building -->
                <div>
                    <label for="building_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">المبنى</label>
                    <select name="building_id" id="building_id" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('building_id') border-red-500 @enderror">
                        <option value="">-- اختر المبنى --</option>
                        @foreach($buildings as $building)
                            <option value="{{ $building->id }}" {{ old('building_id') == $building->id ? 'selected' : '' }}>{{ $building->name }}</option>
                        @endforeach
                    </select>
                    @error('building_id')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Room Number -->
                <div>
                    <label for="room_number" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">رقم الغرفة</label>
                    <input type="text" name="room_number" id="room_number" value="{{ old('room_number') }}" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('room_number') border-red-500 @enderror"
                        placeholder="مثال: 101">
                    @error('room_number')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Floor -->
                <div>
                    <label for="floor" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">الطابق</label>
                    <input type="number" name="floor" id="floor" value="{{ old('floor', 1) }}" min="1" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('floor') border-red-500 @enderror">
                    @error('floor')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Type -->
                <div>
                    <label for="type" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">نوع الغرفة</label>
                    <select name="type" id="type" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('type') border-red-500 @enderror">
                        <option value="single" {{ old('type') == 'single' ? 'selected' : '' }}>فردية</option>
                        <option value="double" {{ old('type', 'double') == 'double' ? 'selected' : '' }}>زوجية</option>
                        <option value="triple" {{ old('type') == 'triple' ? 'selected' : '' }}>ثلاثية</option>
                        <option value="quad" {{ old('type') == 'quad' ? 'selected' : '' }}>رباعية</option>
                    </select>
                    @error('type')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Capacity -->
                <div>
                    <label for="capacity" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">السعة</label>
                    <input type="number" name="capacity" id="capacity" value="{{ old('capacity', 2) }}" min="1" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('capacity') border-red-500 @enderror">
                    @error('capacity')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Price -->
                <div>
                    <label for="price" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">السعر</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500">$</span>
                        <input type="number" name="price" id="price" value="{{ old('price', 0) }}" min="0" step="0.01" required
                            class="w-full pr-10 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('price') border-red-500 @enderror">
                    </div>
                    @error('price')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Description -->
                <div>
                    <label for="description" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">الوصف</label>
                    <textarea name="description" id="description" rows="3"
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white">{{ old('description') }}</textarea>
                </div>
                
                <!-- Buttons -->
                <div class="flex justify-end space-x-3 space-x-reverse">
                    <a href="{{ route('rooms.index') }}" class="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                        إلغاء
                    </a>
                    <button type="submit" class="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg">
                        <i class="fas fa-save ml-2"></i>
                        حفظ
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
