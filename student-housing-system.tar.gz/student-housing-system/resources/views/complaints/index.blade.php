@extends('layouts.app')

@section('title', 'الشكاوى')
@section('page_title', 'إدارة الشكاوى')

@section('content')
<div class="space-y-6">
    <!-- Header & Filters -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white">قائمة الشكاوى</h2>
            @role('student')
            <a href="{{ route('complaints.create') }}" class="mt-4 md:mt-0 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center">
                <i class="fas fa-plus ml-2"></i>
                تقديم شكوى جديدة
            </a>
            @endrole
        </div>
        
        <!-- Filters -->
        <form action="{{ route('complaints.index') }}" method="GET" class="flex flex-col md:flex-row gap-4">
            <div>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الحالة</option>
                    <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>معلقة</option>
                    <option value="in_progress" {{ request('status') == 'in_progress' ? 'selected' : '' }}>قيد التنفيذ</option>
                    <option value="resolved" {{ request('status') == 'resolved' ? 'selected' : '' }}>تم الحل</option>
                    <option value="closed" {{ request('status') == 'closed' ? 'selected' : '' }}>مغلقة</option>
                </select>
            </div>
            <div>
                <select name="type" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">النوع</option>
                    <option value="maintenance" {{ request('type') == 'maintenance' ? 'selected' : '' }}>صيانة</option>
                    <option value="cleaning" {{ request('type') == 'cleaning' ? 'selected' : '' }}>تنظيف</option>
                    <option value="electrical" {{ request('type') == 'electrical' ? 'selected' : '' }}>كهرباء</option>
                    <option value="plumbing" {{ request('type') == 'plumbing' ? 'selected' : '' }}>سباكة</option>
                    <option value="furniture" {{ request('type') == 'furniture' ? 'selected' : '' }}>أثاث</option>
                    <option value="other" {{ request('type') == 'other' ? 'selected' : '' }}>أخرى</option>
                </select>
            </div>
            <div>
                <select name="priority" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الأولوية</option>
                    <option value="low" {{ request('priority') == 'low' ? 'selected' : '' }}>منخفضة</option>
                    <option value="medium" {{ request('priority') == 'medium' ? 'selected' : '' }}>متوسطة</option>
                    <option value="high" {{ request('priority') == 'high' ? 'selected' : '' }}>عالية</option>
                    <option value="urgent" {{ request('priority') == 'urgent' ? 'selected' : '' }}>عاجلة</option>
                </select>
            </div>
            <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg">
                <i class="fas fa-filter"></i>
            </button>
        </form>
    </div>
    
    <!-- Complaints List -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 dark:bg-gray-700">
                <tr>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">العنوان</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الطالب</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">النوع</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الأولوية</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الحالة</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">التاريخ</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الإجراءات</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                @forelse($complaints as $complaint)
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td class="px-6 py-4">
                            <p class="text-sm font-medium text-gray-800 dark:text-white">{{ $complaint->title }}</p>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-800 dark:text-white">{{ $complaint->user->name ?? 'N/A' }}</td>
                        <td class="px-6 py-4 text-sm text-gray-800 dark:text-white">{{ $complaint->type }}</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs rounded-full 
                                {{ $complaint->priority === 'urgent' ? 'bg-red-100 text-red-800' : 
                                   ($complaint->priority === 'high' ? 'bg-orange-100 text-orange-800' : 
                                   ($complaint->priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800')) }}">
                                {{ $complaint->priority }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs rounded-full 
                                {{ $complaint->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                   ($complaint->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                                   ($complaint->status === 'resolved' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800')) }}">
                                {{ $complaint->status }}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500">{{ $complaint->created_at->format('Y-m-d') }}</td>
                        <td class="px-6 py-4">
                            <a href="{{ route('complaints.show', $complaint) }}" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                            <i class="fas fa-clipboard-list text-4xl mb-2"></i>
                            <p>لا توجد شكاوى</p>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <div class="mt-6">
        {{ $complaints->links() }}
    </div>
</div>
@endsection
