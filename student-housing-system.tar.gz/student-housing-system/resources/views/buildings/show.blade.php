@extends('layouts.app')

@section('title', $building->name)
@section('page_title', $building->name)

@section('content')
<div class="space-y-6">
    <!-- Building Info -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <div class="flex justify-between items-start">
            <div>
                <h2 class="text-2xl font-bold text-gray-800 dark:text-white">{{ $building->name }}</h2>
                <p class="text-gray-500 mt-1">{{ $building->code }}</p>
            </div>
            <span class="px-3 py-1 rounded-full text-sm {{ $building->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                {{ $building->is_active ? 'Active' : 'Inactive' }}
            </span>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                <p class="text-sm text-gray-500">Floors</p>
                <p class="text-xl font-bold text-gray-800 dark:text-white">{{ $building->floors_count }}</p>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                <p class="text-sm text-gray-500">Total Rooms</p>
                <p class="text-xl font-bold text-gray-800 dark:text-white">{{ $building->rooms_count }}</p>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                <p class="text-sm text-gray-500">Occupancy Rate</p>
                <p class="text-xl font-bold text-primary-600">{{ $building->occupancy_rate }}%</p>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                <p class="text-sm text-gray-500">Address</p>
                <p class="text-sm text-gray-800 dark:text-white">{{ $building->address ?? 'N/A' }}</p>
            </div>
        </div>
        
        @if($building->description)
            <div class="mt-4">
                <p class="text-sm text-gray-500">Description</p>
                <p class="text-gray-800 dark:text-white">{{ $building->description }}</p>
            </div>
        @endif
    </div>
    
    <!-- Rooms by Floor -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Rooms by Floor</h3>
        
        @forelse($roomsByFloor as $floor => $rooms)
            <div class="mb-6">
                <h4 class="text-md font-medium text-gray-700 dark:text-gray-300 mb-2">Floor {{ $floor }}</h4>
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                    @foreach($rooms as $room)
                        <a href="{{ route('rooms.show', $room) }}" class="p-3 rounded-lg border {{ $room->status === 'available' ? 'border-green-300 bg-green-50 dark:bg-green-900/20' : ($room->status === 'occupied' ? 'border-red-300 bg-red-50 dark:bg-red-900/20' : 'border-yellow-300 bg-yellow-50 dark:bg-yellow-900/20') }}">
                            <p class="text-sm font-medium text-center">{{ $room->room_number }}</p>
                            <p class="text-xs text-center text-gray-500">{{ $room->current_occupancy }}/{{ $room->capacity }}</p>
                        </a>
                    @endforeach
                </div>
            </div>
        @empty
            <p class="text-gray-500 text-center py-4">No rooms found</p>
        @endforelse
    </div>
    
    <!-- Rooms by Status -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Rooms by Status</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            @foreach($roomsByStatus as $status => $rooms)
                <div class="p-4 rounded-lg border {{ $status === 'available' ? 'border-green-300 bg-green-50 dark:bg-green-900/20' : ($status === 'occupied' ? 'border-red-300 bg-red-50 dark:bg-red-900/20' : 'border-yellow-300 bg-yellow-50 dark:bg-yellow-900/20') }}">
                    <p class="text-sm font-medium text-gray-700 dark:text-gray-300 capitalize">{{ $status }}</p>
                    <p class="text-2xl font-bold text-gray-800 dark:text-white">{{ $rooms->count() }}</p>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endsection
