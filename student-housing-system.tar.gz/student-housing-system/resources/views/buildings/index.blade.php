@extends('layouts.app')

@section('title', 'المباني')
@section('page_title', 'إدارة المباني')

@section('content')
<div class="space-y-6">
    <!-- Header -->
    <div class="flex justify-between items-center">
        <h2 class="text-2xl font-bold text-gray-800 dark:text-white">قائمة المباني</h2>
        @role('admin')
        <a href="{{ route('buildings.create') }}" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center">
            <i class="fas fa-plus ml-2"></i>
            إضافة مبنى جديد
        </a>
        @endrole
    </div>
    
    <!-- Buildings Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @forelse($buildings as $building)
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden card-hover">
                <div class="h-32 bg-gradient-to-r from-primary-500 to-primary-700 flex items-center justify-center">
                    <i class="fas fa-building text-6xl text-white opacity-50"></i>
                </div>
                <div class="p-6">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h3 class="text-lg font-bold text-gray-800 dark:text-white">{{ $building->name }}</h3>
                            <p class="text-sm text-gray-500">{{ $building->code }}</p>
                        </div>
                        <span class="px-2 py-1 text-xs rounded-full {{ $building->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                            {{ $building->is_active ? 'نشط' : 'غير نشط' }}
                        </span>
                    </div>
                    
                    <div class="space-y-2 mb-4">
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">عدد الطوابق:</span>
                            <span class="font-medium text-gray-800 dark:text-white">{{ $building->floors_count }}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">عدد الغرف:</span>
                            <span class="font-medium text-gray-800 dark:text-white">{{ $building->rooms_count }}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">نسبة الإشغال:</span>
                            <span class="font-medium text-primary-600">{{ $building->occupancy_rate }}%</span>
                        </div>
                    </div>
                    
                    <div class="flex space-x-2 space-x-reverse">
                        <a href="{{ route('buildings.show', $building) }}" class="flex-1 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 py-2 rounded-lg text-center text-sm">
                            <i class="fas fa-eye ml-1"></i> عرض
                        </a>
                        @role('admin')
                        <a href="{{ route('buildings.edit', $building) }}" class="flex-1 bg-primary-100 dark:bg-primary-900 hover:bg-primary-200 dark:hover:bg-primary-800 text-primary-700 dark:text-primary-300 py-2 rounded-lg text-center text-sm">
                            <i class="fas fa-edit ml-1"></i> تعديل
                        </a>
                        @endrole
                    </div>
                </div>
            </div>
        @empty
            <div class="col-span-full text-center py-12">
                <i class="fas fa-building text-6xl text-gray-300 mb-4"></i>
                <p class="text-gray-500">لا توجد مباني مسجلة</p>
            </div>
        @endforelse
    </div>
    
    <!-- Pagination -->
    <div class="mt-6">
        {{ $buildings->links() }}
    </div>
</div>
@endsection
