@extends('layouts.app')

@section('title', 'تقديم طلب سكن')
@section('page_title', 'تقديم طلب سكن جديد')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <form action="{{ route('applications.store') }}" method="POST">
            @csrf
            
            <div class="space-y-6">
                <!-- Preferred Building -->
                <div>
                    <label for="preferred_building_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">المبنى المفضل (اختياري)</label>
                    <select name="preferred_building_id" id="preferred_building_id"
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                        <option value="">-- اختر المبنى --</option>
                        @foreach($buildings as $building)
                            <option value="{{ $building->id }}" {{ old('preferred_building_id') == $building->id ? 'selected' : '' }}>{{ $building->name }}</option>
                        @endforeach
                    </select>
                </div>
                
                <!-- Preferred Room Type -->
                <div>
                    <label for="preferred_room_type" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">نوع الغرفة المفضل (اختياري)</label>
                    <select name="preferred_room_type" id="preferred_room_type"
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                        <option value="">-- اختر النوع --</option>
                        <option value="single" {{ old('preferred_room_type') == 'single' ? 'selected' : '' }}>فردية</option>
                        <option value="double" {{ old('preferred_room_type') == 'double' ? 'selected' : '' }}>زوجية</option>
                        <option value="triple" {{ old('preferred_room_type') == 'triple' ? 'selected' : '' }}>ثلاثية</option>
                        <option value="quad" {{ old('preferred_room_type') == 'quad' ? 'selected' : '' }}>رباعية</option>
                    </select>
                </div>
                
                <!-- Academic Year -->
                <div>
                    <label for="academic_year" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">السنة الدراسية</label>
                    <select name="academic_year" id="academic_year" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('academic_year') border-red-500 @enderror">
                        @for($i = now()->year; $i <= now()->year + 1; $i++)
                            <option value="{{ $i }}-{{ $i+1 }}" {{ old('academic_year', now()->year.'-'.(now()->year+1)) == $i.'-'.($i+1) ? 'selected' : '' }}>{{ $i }}-{{ $i+1 }}</option>
                        @endfor
                    </select>
                    @error('academic_year')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Semester -->
                <div>
                    <label for="semester" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">الفصل الدراسي</label>
                    <select name="semester" id="semester" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white @error('semester') border-red-500 @enderror">
                        <option value="first" {{ old('semester') == 'first' ? 'selected' : '' }}>الفصل الأول</option>
                        <option value="second" {{ old('semester') == 'second' ? 'selected' : '' }}>الفصل الثاني</option>
                        <option value="summer" {{ old('semester') == 'summer' ? 'selected' : '' }}>فصل الصيف</option>
                    </select>
                    @error('semester')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                
                <!-- Buttons -->
                <div class="flex justify-end space-x-3 space-x-reverse">
                    <a href="{{ route('applications.my') }}" class="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                        إلغاء
                    </a>
                    <button type="submit" class="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg">
                        <i class="fas fa-paper-plane ml-2"></i>
                        تقديم الطلب
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
