@extends('layouts.app')

@section('title', 'طلبات السكن')
@section('page_title', 'إدارة طلبات السكن')

@section('content')
<div class="space-y-6">
    <!-- Header & Filters -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white">قائمة طلبات السكن</h2>
            @role('student')
            <a href="{{ route('applications.create') }}" class="mt-4 md:mt-0 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center">
                <i class="fas fa-plus ml-2"></i>
                تقديم طلب جديد
            </a>
            @endrole
        </div>
        
        <!-- Filters -->
        <form action="{{ route('applications.index') }}" method="GET" class="flex flex-col md:flex-row gap-4">
            <div>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الحالة</option>
                    <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>معلق</option>
                    <option value="approved" {{ request('status') == 'approved' ? 'selected' : '' }}>مقبول</option>
                    <option value="rejected" {{ request('status') == 'rejected' ? 'selected' : '' }}>مرفوض</option>
                    <option value="waitlist" {{ request('status') == 'waitlist' ? 'selected' : '' }}>قائمة الانتظار</option>
                </select>
            </div>
            <div>
                <select name="academic_year" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">السنة الدراسية</option>
                    @for($i = now()->year; $i >= now()->year - 2; $i--)
                        <option value="{{ $i }}-{{ $i+1 }}" {{ request('academic_year') == $i.'-'.($i+1) ? 'selected' : '' }}>{{ $i }}-{{ $i+1 }}</option>
                    @endfor
                </select>
            </div>
            <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg">
                <i class="fas fa-filter"></i>
            </button>
        </form>
    </div>
    
    <!-- Applications List -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 dark:bg-gray-700">
                <tr>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الطالب</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">المبنى المفضل</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">السنة الدراسية</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الفصل</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الحالة</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">تاريخ التقديم</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الإجراءات</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                @forelse($applications as $application)
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td class="px-6 py-4">
                            <p class="text-sm font-medium text-gray-800 dark:text-white">{{ $application->user->name ?? 'N/A' }}</p>
                            <p class="text-xs text-gray-500">{{ $application->user->student_id ?? '' }}</p>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-800 dark:text-white">{{ $application->preferredBuilding->name ?? 'غير محدد' }}</td>
                        <td class="px-6 py-4 text-sm text-gray-800 dark:text-white">{{ $application->academic_year }}</td>
                        <td class="px-6 py-4 text-sm text-gray-800 dark:text-white">{{ $application->semester }}</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs rounded-full 
                                {{ $application->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                   ($application->status === 'approved' ? 'bg-green-100 text-green-800' : 
                                   ($application->status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800')) }}">
                                {{ $application->status }}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500">{{ $application->application_date->format('Y-m-d') }}</td>
                        <td class="px-6 py-4">
                            <a href="{{ route('applications.show', $application) }}" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                            <i class="fas fa-file-alt text-4xl mb-2"></i>
                            <p>لا توجد طلبات سكن</p>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <div class="mt-6">
        {{ $applications->links() }}
    </div>
</div>
@endsection
