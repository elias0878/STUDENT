@extends('layouts.app')

@section('title', 'المدفوعات')
@section('page_title', 'إدارة المدفوعات')

@section('content')
<div class="space-y-6">
    <!-- Header & Filters -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white">قائمة المدفوعات</h2>
            @hasanyrole('admin|accountant')
            <a href="{{ route('payments.create') }}" class="mt-4 md:mt-0 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center">
                <i class="fas fa-plus ml-2"></i>
                إضافة دفعة جديدة
            </a>
            @endhasanyrole
        </div>
        
        <!-- Filters -->
        <form action="{{ route('payments.index') }}" method="GET" class="flex flex-col md:flex-row gap-4">
            <div>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الحالة</option>
                    <option value="paid" {{ request('status') == 'paid' ? 'selected' : '' }}>مدفوع</option>
                    <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>معلق</option>
                    <option value="overdue" {{ request('status') == 'overdue' ? 'selected' : '' }}>متأخر</option>
                </select>
            </div>
            <div>
                <select name="type" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">النوع</option>
                    <option value="rent" {{ request('type') == 'rent' ? 'selected' : '' }}>إيجار</option>
                    <option value="deposit" {{ request('type') == 'deposit' ? 'selected' : '' }}>تأمين</option>
                    <option value="service" {{ request('type') == 'service' ? 'selected' : '' }}>خدمة</option>
                    <option value="fine" {{ request('type') == 'fine' ? 'selected' : '' }}>غرامة</option>
                </select>
            </div>
            <div>
                <select name="student" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <option value="">الطالب</option>
                    @foreach($students as $student)
                        <option value="{{ $student->id }}" {{ request('student') == $student->id ? 'selected' : '' }}>{{ $student->name }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg">
                <i class="fas fa-filter"></i>
            </button>
        </form>
    </div>
    
    <!-- Payments List -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 dark:bg-gray-700">
                <tr>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الطالب</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">المبلغ</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">النوع</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">تاريخ الاستحقاق</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الحالة</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">الإجراءات</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                @forelse($payments as $payment)
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td class="px-6 py-4">
                            <p class="text-sm font-medium text-gray-800 dark:text-white">{{ $payment->user->name ?? 'N/A' }}</p>
                            <p class="text-xs text-gray-500">{{ $payment->user->student_id ?? '' }}</p>
                        </td>
                        <td class="px-6 py-4 text-sm font-medium text-gray-800 dark:text-white">${{ number_format($payment->amount, 2) }}</td>
                        <td class="px-6 py-4 text-sm text-gray-800 dark:text-white">{{ $payment->payment_type }}</td>
                        <td class="px-6 py-4 text-sm text-gray-800 dark:text-white">{{ $payment->due_date->format('Y-m-d') }}</td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs rounded-full 
                                {{ $payment->status === 'paid' ? 'bg-green-100 text-green-800' : 
                                   ($payment->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                   ($payment->status === 'overdue' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800')) }}">
                                {{ $payment->status }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex space-x-2 space-x-reverse">
                                <a href="{{ route('payments.show', $payment) }}" class="text-blue-600 hover:text-blue-800">
                                    <i class="fas fa-eye"></i>
                                </a>
                                @if($payment->status !== 'paid')
                                    <form action="{{ route('payments.record', $payment) }}" method="POST" class="inline">
                                        @csrf
                                        <button type="submit" class="text-green-600 hover:text-green-800" onclick="return confirm('تأكيد تسجيل الدفع؟')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-gray-500">
                            <i class="fas fa-money-bill-wave text-4xl mb-2"></i>
                            <p>لا توجد مدفوعات</p>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <div class="mt-6">
        {{ $payments->links() }}
    </div>
</div>
@endsection
