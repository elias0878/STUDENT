@extends('layouts.app')

@section('title', 'لوحة التحكم')
@section('page_title', 'لوحة التحكم')

@section('content')
<div class="space-y-6">
    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Total Students -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 card-hover">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">إجمالي الطلاب</p>
                    <p class="text-2xl font-bold text-gray-800 dark:text-white mt-1">{{ $stats['total_students'] }}</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                    <i class="fas fa-users text-blue-600 dark:text-blue-400 text-xl"></i>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm">
                <span class="text-green-500 flex items-center">
                    <i class="fas fa-arrow-up mr-1"></i>
                    {{ $stats['active_students'] }}
                </span>
                <span class="text-gray-400 mr-2">نشط</span>
            </div>
        </div>
        
        <!-- Total Rooms -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 card-hover">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">إجمالي الغرف</p>
                    <p class="text-2xl font-bold text-gray-800 dark:text-white mt-1">{{ $stats['total_rooms'] }}</p>
                </div>
                <div class="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                    <i class="fas fa-door-open text-green-600 dark:text-green-400 text-xl"></i>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm space-x-4 space-x-reverse">
                <span class="text-green-500">{{ $stats['available_rooms'] }} متاح</span>
                <span class="text-red-500">{{ $stats['occupied_rooms'] }} مشغول</span>
            </div>
        </div>
        
        <!-- Occupancy Rate -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 card-hover">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">نسبة الإشغال</p>
                    <p class="text-2xl font-bold text-gray-800 dark:text-white mt-1">{{ $occupancyRate }}%</p>
                </div>
                <div class="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center">
                    <i class="fas fa-chart-pie text-purple-600 dark:text-purple-400 text-xl"></i>
                </div>
            </div>
            <div class="mt-4">
                <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div class="bg-purple-600 h-2 rounded-full transition-all duration-500" style="width: {{ $occupancyRate }}%"></div>
                </div>
            </div>
        </div>
        
        <!-- Monthly Payments -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 card-hover">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">مدفوعات الشهر</p>
                    <p class="text-2xl font-bold text-gray-800 dark:text-white mt-1">${{ number_format($stats['monthly_payments'], 2) }}</p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 dark:bg-yellow-900 rounded-full flex items-center justify-center">
                    <i class="fas fa-dollar-sign text-yellow-600 dark:text-yellow-400 text-xl"></i>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm space-x-4 space-x-reverse">
                <span class="text-orange-500">{{ $stats['pending_payments'] }} معلق</span>
                <span class="text-red-500">{{ $stats['overdue_payments'] }} متأخر</span>
            </div>
        </div>
    </div>
    
    <!-- Charts Row -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Monthly Occupancy Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                <i class="fas fa-chart-line text-primary-500 mr-2"></i>
                الإشغال الشهري
            </h3>
            <div class="h-64">
                <canvas id="occupancyChart"></canvas>
            </div>
        </div>
        
        <!-- Monthly Payments Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                <i class="fas fa-chart-bar text-primary-500 mr-2"></i>
                المدفوعات الشهرية
            </h3>
            <div class="h-64">
                <canvas id="paymentsChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Complaints by Type & Recent Activity -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Complaints by Type -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                <i class="fas fa-exclamation-triangle text-primary-500 mr-2"></i>
                الشكاوى حسب النوع
            </h3>
            <div class="space-y-3">
                @forelse($complaintsByType as $type)
                    <div class="flex items-center justify-between">
                        <span class="text-gray-600 dark:text-gray-400">
                            @switch($type->type)
                                @case('maintenance') صيانة @break
                                @case('cleaning') تنظيف @break
                                @case('electrical') كهرباء @break
                                @case('plumbing') سباكة @break
                                @case('furniture') أثاث @break
                                @default أخرى @break
                            @endswitch
                        </span>
                        <div class="flex items-center">
                            <div class="w-32 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-3">
                                @php
                                    $maxCount = $complaintsByType->max('count') ?: 1;
                                    $percentage = ($type->count / $maxCount) * 100;
                                @endphp
                                <div class="bg-primary-600 h-2 rounded-full" style="width: {{ $percentage }}%"></div>
                            </div>
                            <span class="text-sm font-medium text-gray-700 dark:text-gray-300">{{ $type->count }}</span>
                        </div>
                    </div>
                @empty
                    <p class="text-gray-500 text-center py-4">لا توجد شكاوى</p>
                @endforelse
            </div>
        </div>
        
        <!-- Recent Complaints -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                <i class="fas fa-clock text-primary-500 mr-2"></i>
                آخر الشكاوى
            </h3>
            <div class="space-y-3">
                @forelse($recentComplaints as $complaint)
                    <div class="flex items-start space-x-3 space-x-reverse p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div class="w-8 h-8 rounded-full bg-{{ $complaint->priority === 'urgent' ? 'red' : ($complaint->priority === 'high' ? 'orange' : 'blue') }}-100 flex items-center justify-center flex-shrink-0">
                            <i class="fas fa-exclamation text-{{ $complaint->priority === 'urgent' ? 'red' : ($complaint->priority === 'high' ? 'orange' : 'blue') }}-600 text-sm"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-gray-800 dark:text-white truncate">{{ $complaint->title }}</p>
                            <p class="text-xs text-gray-500">{{ $complaint->user->name ?? 'Unknown' }} - {{ $complaint->created_at->diffForHumans() }}</p>
                        </div>
                        <span class="px-2 py-1 text-xs rounded-full 
                            {{ $complaint->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                               ($complaint->status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                               ($complaint->status === 'resolved' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800')) }}">
                            {{ $complaint->status === 'pending' ? 'معلق' : 
                               ($complaint->status === 'in_progress' ? 'قيد التنفيذ' : 
                               ($complaint->status === 'resolved' ? 'تم الحل' : 'مغلق')) }}
                        </span>
                    </div>
                @empty
                    <p class="text-gray-500 text-center py-4">لا توجد شكاوى حديثة</p>
                @endforelse
            </div>
        </div>
        
        <!-- Recent Payments -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                <i class="fas fa-money-bill-wave text-primary-500 mr-2"></i>
                آخر المدفوعات
            </h3>
            <div class="space-y-3">
                @forelse($recentPayments as $payment)
                    <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div class="flex items-center space-x-3 space-x-reverse">
                            <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                                <i class="fas fa-check text-green-600 text-sm"></i>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-800 dark:text-white">{{ $payment->user->name ?? 'Unknown' }}</p>
                                <p class="text-xs text-gray-500">{{ $payment->payment_date->format('Y-m-d') }}</p>
                            </div>
                        </div>
                        <span class="text-sm font-bold text-green-600">${{ number_format($payment->amount, 2) }}</span>
                    </div>
                @empty
                    <p class="text-gray-500 text-center py-4">لا توجد مدفوعات حديثة</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Occupancy Chart
    const occupancyCtx = document.getElementById('occupancyChart').getContext('2d');
    new Chart(occupancyCtx, {
        type: 'line',
        data: {
            labels: {!! json_encode(array_column($monthlyOccupancy, 'month')) !!},
            datasets: [{
                label: 'نسبة الإشغال (%)',
                data: {!! json_encode(array_column($monthlyOccupancy, 'rate')) !!},
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
    
    // Payments Chart
    const paymentsCtx = document.getElementById('paymentsChart').getContext('2d');
    new Chart(paymentsCtx, {
        type: 'bar',
        data: {
            labels: {!! json_encode(array_column($monthlyPayments, 'month')) !!},
            datasets: [{
                label: 'المبلغ ($)',
                data: {!! json_encode(array_column($monthlyPayments, 'amount')) !!},
                backgroundColor: '#10b981',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
@endpush
