<!-- Footer -->
<footer class="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-4 px-6">
    <div class="flex flex-col md:flex-row items-center justify-between">
        <div class="text-sm text-gray-600 dark:text-gray-400">
            &copy; {{ date('Y') }} نظام إدارة سكن الطلاب. جميع الحقوق محفوظة.
        </div>
        <div class="flex items-center space-x-4 space-x-reverse mt-2 md:mt-0">
            <span class="text-sm text-gray-500 dark:text-gray-400">
                <i class="fas fa-code mr-1"></i>
                نسخة 1.0
            </span>
        </div>
    </div>
</footer>
