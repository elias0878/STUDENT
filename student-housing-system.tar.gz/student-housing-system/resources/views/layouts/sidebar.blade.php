<!-- Sidebar -->
<aside id="sidebar" class="fixed inset-y-0 right-0 z-50 w-64 bg-white dark:bg-gray-800 shadow-xl transform -translate-x-full lg:translate-x-0 sidebar-transition border-l border-gray-200 dark:border-gray-700">
    <!-- Logo -->
    <div class="flex items-center justify-between h-16 px-6 bg-primary-600 dark:bg-primary-800">
        <a href="{{ route('dashboard') }}" class="flex items-center space-x-3 space-x-reverse">
            <i class="fas fa-university text-white text-2xl"></i>
            <span class="text-white text-lg font-bold">سكن الطلاب</span>
        </a>
        <button onclick="toggleSidebar()" class="lg:hidden text-white">
            <i class="fas fa-times text-xl"></i>
        </button>
    </div>
    
    <!-- Navigation -->
    <nav class="mt-6 px-4 space-y-2 overflow-y-auto h-[calc(100vh-4rem)]">
        <!-- Dashboard -->
        <a href="{{ route('dashboard') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('dashboard') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-tachometer-alt w-6"></i>
            <span class="mr-3 font-medium">لوحة التحكم</span>
        </a>
        
        @role('admin')
        <!-- Buildings -->
        <a href="{{ route('buildings.index') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('buildings.*') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-building w-6"></i>
            <span class="mr-3 font-medium">المباني</span>
        </a>
        @endrole
        
        @hasanyrole('admin|supervisor')
        <!-- Rooms -->
        <a href="{{ route('rooms.index') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('rooms.*') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-door-open w-6"></i>
            <span class="mr-3 font-medium">الغرف</span>
        </a>
        @endhasanyrole
        
        @hasanyrole('admin|supervisor')
        <!-- Students -->
        <a href="{{ route('students.index') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('students.*') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-users w-6"></i>
            <span class="mr-3 font-medium">الطلاب</span>
        </a>
        @endhasanyrole
        
        <!-- Complaints -->
        <a href="{{ route('complaints.index') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('complaints.*') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-exclamation-circle w-6"></i>
            <span class="mr-3 font-medium">الشكاوى</span>
            @php
                $pendingComplaints = App\Models\Complaint::where('status', 'pending')->count();
            @endphp
            @if($pendingComplaints > 0)
                <span class="mr-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">{{ $pendingComplaints }}</span>
            @endif
        </a>
        
        @hasanyrole('admin|accountant')
        <!-- Payments -->
        <a href="{{ route('payments.index') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('payments.*') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-money-bill-wave w-6"></i>
            <span class="mr-3 font-medium">المدفوعات</span>
        </a>
        @endhasanyrole
        
        <!-- Housing Applications -->
        <a href="{{ route('applications.index') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('applications.*') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-file-alt w-6"></i>
            <span class="mr-3 font-medium">طلبات السكن</span>
            @php
                $pendingApps = App\Models\HousingApplication::where('status', 'pending')->count();
            @endphp
            @if($pendingApps > 0)
                <span class="mr-auto bg-orange-500 text-white text-xs px-2 py-1 rounded-full">{{ $pendingApps }}</span>
            @endif
        </a>
        
        @role('admin')
        <!-- Excel Import/Export -->
        <div class="pt-4 pb-2">
            <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">استيراد/تصدير</p>
        </div>
        
        <a href="{{ route('excel.import') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('excel.import') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-file-import w-6"></i>
            <span class="mr-3 font-medium">استيراد البيانات</span>
        </a>
        
        <a href="{{ route('excel.export') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('excel.export') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-file-export w-6"></i>
            <span class="mr-3 font-medium">تصدير البيانات</span>
        </a>
        @endrole
        
        <!-- Student Section -->
        @role('student')
        <div class="pt-4 pb-2">
            <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">خدماتي</p>
        </div>
        
        <a href="{{ route('complaints.my') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('complaints.my') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-clipboard-list w-6"></i>
            <span class="mr-3 font-medium">شكاواي</span>
        </a>
        
        <a href="{{ route('payments.my') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('payments.my') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-credit-card w-6"></i>
            <span class="mr-3 font-medium">مدفوعاتي</span>
        </a>
        
        <a href="{{ route('applications.my') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('applications.my') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-home w-6"></i>
            <span class="mr-3 font-medium">طلباتي</span>
        </a>
        @endrole
        
        <!-- Settings -->
        <div class="pt-4 pb-2">
            <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">الإعدادات</p>
        </div>
        
        <a href="{{ route('profile.edit') }}" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 dark:hover:text-primary-400 transition-colors {{ request()->routeIs('profile.*') ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-r-4 border-primary-600' : '' }}">
            <i class="fas fa-user-cog w-6"></i>
            <span class="mr-3 font-medium">الملف الشخصي</span>
        </a>
    </nav>
</aside>

<!-- Sidebar Overlay (Mobile) -->
<div id="sidebar-overlay" onclick="toggleSidebar()" class="fixed inset-0 bg-black bg-opacity-50 z-40 hidden lg:hidden"></div>
