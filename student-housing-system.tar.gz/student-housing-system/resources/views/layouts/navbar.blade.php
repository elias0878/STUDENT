<!-- Navbar -->
<header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
    <div class="flex items-center justify-between h-16 px-6">
        <!-- Left Side -->
        <div class="flex items-center space-x-4 space-x-reverse">
            <!-- Mobile Menu Button -->
            <button onclick="toggleSidebar()" class="lg:hidden text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300">
                <i class="fas fa-bars text-xl"></i>
            </button>
            
            <!-- Page Title -->
            <h1 class="text-xl font-semibold text-gray-800 dark:text-white">
                @yield('page_title', 'لوحة التحكم')
            </h1>
        </div>
        
        <!-- Right Side -->
        <div class="flex items-center space-x-4 space-x-reverse">
            <!-- Dark Mode Toggle -->
            <button onclick="toggleDarkMode()" class="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors" title="تبديل الوضع">
                <i class="fas fa-moon dark:hidden text-xl"></i>
                <i class="fas fa-sun hidden dark:block text-xl text-yellow-400"></i>
            </button>
            
            <!-- Notifications -->
            <div class="relative">
                <button onclick="toggleNotifications()" class="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors relative">
                    <i class="fas fa-bell text-xl"></i>
                    @php
                        $unreadNotifications = auth()->user() ? auth()->user()->unreadNotifications->count() : 0;
                    @endphp
                    @if($unreadNotifications > 0)
                        <span class="absolute top-0 right-0 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">{{ $unreadNotifications }}</span>
                    @endif
                </button>
                
                <!-- Notifications Dropdown -->
                <div id="notifications-dropdown" class="hidden absolute left-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50">
                    <div class="p-4 border-b border-gray-200 dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-gray-800 dark:text-white">الإشعارات</h3>
                    </div>
                    <div class="max-h-64 overflow-y-auto">
                        @if(auth()->user() && auth()->user()->notifications->count() > 0)
                            @foreach(auth()->user()->notifications->take(5) as $notification)
                                <div class="p-4 border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 {{ $notification->read_at ? 'opacity-60' : '' }}">
                                    <p class="text-sm text-gray-800 dark:text-gray-200">{{ $notification->data['message'] ?? 'New notification' }}</p>
                                    <p class="text-xs text-gray-500 mt-1">{{ $notification->created_at->diffForHumans() }}</p>
                                </div>
                            @endforeach
                        @else
                            <div class="p-4 text-center text-gray-500">
                                <i class="fas fa-inbox text-3xl mb-2"></i>
                                <p>لا توجد إشعارات</p>
                            </div>
                        @endif
                    </div>
                    <div class="p-3 border-t border-gray-200 dark:border-gray-700 text-center">
                        <a href="#" class="text-sm text-primary-600 hover:text-primary-700">عرض الكل</a>
                    </div>
                </div>
            </div>
            
            <!-- User Menu -->
            <div class="relative">
                <button onclick="toggleUserMenu()" class="flex items-center space-x-3 space-x-reverse p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                    <img src="{{ auth()->user()->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode(auth()->user()->name) . '&background=3b82f6&color=fff' }}" alt="{{ auth()->user()->name }}" class="w-8 h-8 rounded-full">
                    <div class="hidden md:block text-right">
                        <p class="text-sm font-medium text-gray-800 dark:text-white">{{ auth()->user()->name }}</p>
                        <p class="text-xs text-gray-500 dark:text-gray-400">{{ auth()->user()->roles->first()->name ?? 'User' }}</p>
                    </div>
                    <i class="fas fa-chevron-down text-gray-400 text-sm"></i>
                </button>
                
                <!-- User Dropdown -->
                <div id="user-dropdown" class="hidden absolute left-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50">
                    <div class="p-3 border-b border-gray-200 dark:border-gray-700">
                        <p class="text-sm font-medium text-gray-800 dark:text-white">{{ auth()->user()->name }}</p>
                        <p class="text-xs text-gray-500">{{ auth()->user()->email }}</p>
                    </div>
                    <a href="{{ route('profile.edit') }}" class="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                        <i class="fas fa-user mr-2"></i> الملف الشخصي
                    </a>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="w-full text-right px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20">
                            <i class="fas fa-sign-out-alt mr-2"></i> تسجيل الخروج
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
    function toggleNotifications() {
        const dropdown = document.getElementById('notifications-dropdown');
        dropdown.classList.toggle('hidden');
        
        // Close user menu if open
        document.getElementById('user-dropdown').classList.add('hidden');
    }
    
    function toggleUserMenu() {
        const dropdown = document.getElementById('user-dropdown');
        dropdown.classList.toggle('hidden');
        
        // Close notifications if open
        document.getElementById('notifications-dropdown').classList.add('hidden');
    }
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        const notificationsDropdown = document.getElementById('notifications-dropdown');
        const userDropdown = document.getElementById('user-dropdown');
        
        if (!event.target.closest('.relative')) {
            notificationsDropdown.classList.add('hidden');
            userDropdown.classList.add('hidden');
        }
    });
</script>
