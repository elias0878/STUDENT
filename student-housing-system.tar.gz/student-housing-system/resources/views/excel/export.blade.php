@extends('layouts.app')

@section('title', 'تصدير البيانات')
@section('page_title', 'تصدير البيانات إلى Excel')

@section('content')
<div class="max-w-2xl mx-auto space-y-6">
    <!-- Export Residents -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            <i class="fas fa-users text-primary-500 mr-2"></i>
            تصدير كشف المقيمين
        </h3>
        
        <p class="text-gray-600 dark:text-gray-400 mb-4">
            تصدير قائمة بجميع الطلاب المقيمين مع تفاصيل غرفهم.
        </p>
        
        <a href="{{ route('excel.export.residents') }}" class="inline-flex items-center bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">
            <i class="fas fa-file-excel ml-2"></i>
            تصدير كشف المقيمين
        </a>
    </div>
    
    <!-- Export Payments -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            <i class="fas fa-money-bill-wave text-primary-500 mr-2"></i>
            تصدير تقرير المدفوعات
        </h3>
        
        <form action="{{ route('excel.export.payments') }}" method="GET" class="space-y-4">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label for="month" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">الشهر</label>
                    <select name="month" id="month" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                        @for($i = 1; $i <= 12; $i++)
                            <option value="{{ $i }}" {{ $i == now()->month ? 'selected' : '' }}>{{ $i }}</option>
                        @endfor
                    </select>
                </div>
                <div>
                    <label for="year" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">السنة</label>
                    <select name="year" id="year" class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                        @for($i = now()->year - 2; $i <= now()->year + 1; $i++)
                            <option value="{{ $i }}" {{ $i == now()->year ? 'selected' : '' }}>{{ $i }}</option>
                        @endfor
                    </select>
                </div>
            </div>
            
            <div class="flex justify-end">
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">
                    <i class="fas fa-file-excel ml-2"></i>
                    تصدير تقرير المدفوعات
                </button>
            </div>
        </form>
    </div>
    
    <!-- Export Available Rooms -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            <i class="fas fa-door-open text-primary-500 mr-2"></i>
            تصدير الغرف المتاحة
        </h3>
        
        <p class="text-gray-600 dark:text-gray-400 mb-4">
            تصدير قائمة بالغرف المتاحة للسكن.
        </p>
        
        <a href="{{ route('excel.export.rooms') }}" class="inline-flex items-center bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">
            <i class="fas fa-file-excel ml-2"></i>
            تصدير الغرف المتاحة
        </a>
    </div>
</div>
@endsection
