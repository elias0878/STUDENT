@extends('layouts.app')

@section('title', 'استيراد البيانات')
@section('page_title', 'استيراد البيانات من Excel')

@section('content')
<div class="max-w-2xl mx-auto space-y-6">
    <!-- Import Students -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            <i class="fas fa-users text-primary-500 mr-2"></i>
            استيراد الطلاب
        </h3>
        
        <form action="{{ route('excel.import.students') }}" method="POST" enctype="multipart/form-data">
            @csrf
            
            <div class="space-y-4">
                <div>
                    <label for="students_file" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">ملف Excel (الطلاب)</label>
                    <input type="file" name="file" id="students_file" accept=".xlsx,.xls,.csv" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <p class="text-sm text-gray-500 mt-1">الأعمدة المطلوبة: name, email, phone, student_id</p>
                </div>
                
                <div class="flex justify-end">
                    <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-lg">
                        <i class="fas fa-file-import ml-2"></i>
                        استيراد الطلاب
                    </button>
                </div>
            </div>
        </form>
    </div>
    
    <!-- Import Rooms -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">
            <i class="fas fa-door-open text-primary-500 mr-2"></i>
            استيراد الغرف
        </h3>
        
        <form action="{{ route('excel.import.rooms') }}" method="POST" enctype="multipart/form-data">
            @csrf
            
            <div class="space-y-4">
                <div>
                    <label for="rooms_file" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">ملف Excel (الغرف)</label>
                    <input type="file" name="file" id="rooms_file" accept=".xlsx,.xls,.csv" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white dark:bg-gray-700 text-gray-800 dark:text-white">
                    <p class="text-sm text-gray-500 mt-1">الأعمدة المطلوبة: building_code, room_number, floor, type, capacity, price</p>
                </div>
                
                <div class="flex justify-end">
                    <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-lg">
                        <i class="fas fa-file-import ml-2"></i>
                        استيراد الغرف
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
