# نظام إدارة سكن الطلاب الذكي

## Smart Student Housing Management System

نظام شامل لإدارة سكن الطلاب مع دعم متعدد الأدوار والميزات المتقدمة.

## المتطلبات

- PHP >= 8.1
- Composer
- MySQL >= 5.7
- Node.js & NPM (لـ Tailwind CSS)

## التثبيت

1. استنساخ المشروع:
```bash
git clone <repository-url>
cd student-housing-system
```

2. تثبيت الاعتمادات:
```bash
composer install
npm install
```

3. إعداد ملف البيئة:
```bash
cp .env.example .env
php artisan key:generate
```

4. تعديل إعدادات قاعدة البيانات في ملف `.env`:
```
DB_DATABASE=student_housing
DB_USERNAME=root
DB_PASSWORD=your_password
```

5. تشغيل المهاجرات وملء البيانات الأولية:
```bash
php artisan migrate --seed
```

6. إعداد Sanctum:
```bash
php artisan sanctum:install
```

7. تشغيل الخادم:
```bash
php artisan serve
```

## الميزات الرئيسية

### 1. نظام المصادقة والأدوار (Laravel Breeze)
- Admin: إدارة كاملة للنظام
- Supervisor: إدارة الغرف والطلاب والشكاوى
- Accountant: إدارة المدفوعات
- Student: عرض الغرفة والشكاوى والمدفوعات

### 2. إدارة الغرف
- عرض حالة الغرف (متاحة - مشغولة - تحت الصيانة)
- تصفية حسب المبنى والطابق والنوع
- إدارة السعة والإشغال

### 3. Excel Import/Export
- استيراد قائمة الطلاب
- استيراد الغرف والأسعار
- تصدير كشف المقيمين
- تصدير تقرير المدفوعات
- تصدير الغرف الفارغة

### 4. العلاقات (Relations)
- One-to-Many: الغرفة → المبنى، الطلاب → الغرفة، الشكاوى → الطلاب
- Many-to-Many: الخدمات ↔ الطلاب، فقاعات الإنترنت

### 5. Sanctum API
- API كامل للتطبيق المحمول
- عرض الغرف المتاحة
- إرسال شكوى
- عرض سجل المدفوعات
- تسجيل الدخول باستخدام Token

### 6. لوحة التحكم والإحصائيات
- عدد الطلاب المقيمين
- نسبة الإشغال
- أكثر أنواع الشكاوى
- الإشغال الشهري
- المدفوعات حسب الشهر
- عدد الشكاوى المفتوحة

### 7. أوامر Artisan
- حساب نسبة الإشغال يومياً
- إرسال تذكير عند تأخر الدفع

### 8. Blade Layouts
- استخدام @extends, @section, @yield, @include
- واجهة موحدة مع Sidebar و Navbar

### 9. Dark/Light Mode
- دعم الوضع الليلي والنهاري باستخدام Tailwind

### 10. Middleware
- الطلاب فقط يمكنهم إرسال شكوى
- المحاسب فقط يرى المدفوعات
- المشرف فقط يدير الغرف
- المدير فقط يدير المستخدمين

### 11. نظام الإشعارات
- إشعارات عند قبول طلب السكن
- إشعارات عبر قاعدة البيانات والبريد الإلكتروني

## الحسابات التجريبية

| الدور | البريد الإلكتروني | كلمة المرور |
|-------|------------------|-------------|
| Admin | admin@housing.com | password |
| Supervisor | supervisor@housing.com | password |
| Accountant | accountant@housing.com | password |
| Student | ahmed@student.com | password |

## API Endpoints

### المصادقة
- `POST /api/login` - تسجيل الدخول
- `POST /api/logout` - تسجيل الخروج
- `GET /api/user` - بيانات المستخدم

### الغرف
- `GET /api/rooms` - قائمة الغرف
- `GET /api/rooms/available` - الغرف المتاحة
- `GET /api/rooms/{room}` - تفاصيل غرفة
- `GET /api/my-room` - غرفتي

### الشكاوى
- `GET /api/complaints` - قائمة الشكاوى
- `POST /api/complaints` - إرسال شكوى
- `GET /api/complaints/{complaint}` - تفاصيل شكوى

### المدفوعات
- `GET /api/payments` - قائمة المدفوعات
- `GET /api/payments/pending/list` - المدفوعات المعلقة
- `GET /api/payments/history/list` - سجل المدفوعات

## الأوامر المجدولة

إضافة الأوامر التالية إلى cron job:

```bash
# حساب نسبة الإشغال يومياً
0 0 * * * cd /path/to/project && php artisan occupancy:calculate >> /dev/null 2>&1

# إرسال تذكير بالمدفوعات المتأخرة
0 9 * * * cd /path/to/project && php artisan payments:send-reminders >> /dev/null 2>&1
```

## المساهمة

نرحب بمساهماتكم! يرجى اتباع الخطوات التالية:

1. Fork المشروع
2. إنشاء فرع للميزة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## الترخيص

هذا المشروع مرخص بموجب [MIT License](LICENSE).

## التواصل

للاستفسارات والدعم، يرجى التواصل عبر:
- البريد الإلكتروني: support@housing.com
- GitHub Issues

---

**تم إنشاء هذا المشروع باستخدام Laravel 10 + Tailwind CSS + Spatie Permission + Laravel Sanctum + Maatwebsite Excel**
