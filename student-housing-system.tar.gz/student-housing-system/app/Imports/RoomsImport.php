<?php

namespace App\Imports;

use App\Models\Building;
use App\Models\Room;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class RoomsImport implements ToModel, WithHeadingRow, WithValidation
{
    public function model(array $row)
    {
        $building = Building::firstOrCreate(
            ['code' => $row['building_code']],
            [
                'name' => $row['building_name'] ?? $row['building_code'],
                'floors_count' => $row['floors_count'] ?? 1,
                'is_active' => true,
            ]
        );

        return new Room([
            'building_id' => $building->id,
            'room_number' => $row['room_number'],
            'floor' => $row['floor'] ?? 1,
            'type' => $row['type'] ?? 'double',
            'capacity' => $row['capacity'] ?? 2,
            'current_occupancy' => $row['current_occupancy'] ?? 0,
            'status' => $row['status'] ?? 'available',
            'price' => $row['price'] ?? 0,
            'description' => $row['description'] ?? null,
            'amenities' => json_encode(explode(',', $row['amenities'] ?? '')),
        ]);
    }

    public function rules(): array
    {
        return [
            'building_code' => 'required|string|max:50',
            'room_number' => 'required|string|max:50',
            'floor' => 'nullable|integer|min:1',
            'type' => 'nullable|in:single,double,triple,quad',
            'capacity' => 'nullable|integer|min:1',
            'price' => 'nullable|numeric|min:0',
        ];
    }
}
