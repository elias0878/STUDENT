<?php

namespace App\Http\Controllers;

use App\Models\Building;
use Illuminate\Http\Request;

class BuildingController extends Controller
{
    public function index()
    {
        $buildings = Building::withCount('rooms')
            ->with(['rooms' => function($query) {
                $query->select('id', 'building_id', 'status');
            }])
            ->latest()
            ->paginate(10);

        return view('buildings.index', compact('buildings'));
    }

    public function create()
    {
        return view('buildings.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'required|string|max:50|unique:buildings',
            'address' => 'nullable|string',
            'floors_count' => 'required|integer|min:1',
            'description' => 'nullable|string',
        ]);

        Building::create($validated);

        return redirect()->route('buildings.index')
            ->with('success', 'Building created successfully.');
    }

    public function show(Building $building)
    {
        $building->load(['rooms' => function($query) {
            $query->withCount('students');
        }]);

        $roomsByFloor = $building->rooms->groupBy('floor');
        $roomsByStatus = $building->rooms->groupBy('status');

        return view('buildings.show', compact('building', 'roomsByFloor', 'roomsByStatus'));
    }

    public function edit(Building $building)
    {
        return view('buildings.edit', compact('building'));
    }

    public function update(Request $request, Building $building)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'required|string|max:50|unique:buildings,code,' . $building->id,
            'address' => 'nullable|string',
            'floors_count' => 'required|integer|min:1',
            'description' => 'nullable|string',
            'is_active' => 'boolean',
        ]);

        $building->update($validated);

        return redirect()->route('buildings.index')
            ->with('success', 'Building updated successfully.');
    }

    public function destroy(Building $building)
    {
        if ($building->rooms()->count() > 0) {
            return redirect()->route('buildings.index')
                ->with('error', 'Cannot delete building with rooms.');
        }

        $building->delete();

        return redirect()->route('buildings.index')
            ->with('success', 'Building deleted successfully.');
    }
}
