<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class StudentController extends Controller
{
    public function index(Request $request)
    {
        $query = User::role('student')->with('room');

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('student_id', 'like', "%{$search}%");
            });
        }

        if ($request->filled('room')) {
            $query->where('room_id', $request->room);
        }

        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $students = $query->latest()->paginate(20);
        $rooms = Room::available()->get();

        return view('students.index', compact('students', 'rooms'));
    }

    public function create()
    {
        $rooms = Room::where('status', 'available')
            ->whereColumn('current_occupancy', '<', 'capacity')
            ->get();
        return view('students.create', compact('rooms'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'phone' => 'nullable|string|max:20',
            'student_id' => 'nullable|string|unique:users',
            'room_id' => 'nullable|exists:rooms,id',
        ]);

        $validated['password'] = Hash::make($validated['password']);

        $student = User::create($validated);
        $student->assignRole('student');

        if ($request->room_id) {
            $room = Room::find($request->room_id);
            $room->increment('current_occupancy');
            if ($room->isFull()) {
                $room->update(['status' => 'occupied']);
            }
        }

        return redirect()->route('students.index')
            ->with('success', 'Student created successfully.');
    }

    public function show(User $student)
    {
        $student->load(['room.building', 'complaints', 'payments']);
        return view('students.show', compact('student'));
    }

    public function edit(User $student)
    {
        $rooms = Room::where('status', 'available')
            ->orWhere('id', $student->room_id)
            ->get();
        return view('students.edit', compact('student', 'rooms'));
    }

    public function update(Request $request, User $student)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $student->id,
            'phone' => 'nullable|string|max:20',
            'student_id' => 'nullable|string|unique:users,student_id,' . $student->id,
            'room_id' => 'nullable|exists:rooms,id',
            'is_active' => 'boolean',
        ]);

        $oldRoomId = $student->room_id;
        $newRoomId = $request->room_id;

        $student->update($validated);

        if ($oldRoomId != $newRoomId) {
            if ($oldRoomId) {
                $oldRoom = Room::find($oldRoomId);
                $oldRoom->decrement('current_occupancy');
                $oldRoom->update(['status' => 'available']);
            }

            if ($newRoomId) {
                $newRoom = Room::find($newRoomId);
                $newRoom->increment('current_occupancy');
                if ($newRoom->isFull()) {
                    $newRoom->update(['status' => 'occupied']);
                }
            }
        }

        return redirect()->route('students.index')
            ->with('success', 'Student updated successfully.');
    }

    public function destroy(User $student)
    {
        if ($student->room_id) {
            $room = Room::find($student->room_id);
            $room->decrement('current_occupancy');
            $room->update(['status' => 'available']);
        }

        $student->delete();

        return redirect()->route('students.index')
            ->with('success', 'Student deleted successfully.');
    }

    public function assignRoom(Request $request, User $student)
    {
        $validated = $request->validate([
            'room_id' => 'required|exists:rooms,id',
        ]);

        $room = Room::find($validated['room_id']);

        if (!$room->isAvailable()) {
            return redirect()->back()
                ->with('error', 'Room is not available.');
        }

        if ($student->room_id) {
            $oldRoom = Room::find($student->room_id);
            $oldRoom->decrement('current_occupancy');
            $oldRoom->update(['status' => 'available']);
        }

        $student->update(['room_id' => $room->id]);
        $room->increment('current_occupancy');

        if ($room->isFull()) {
            $room->update(['status' => 'occupied']);
        }

        return redirect()->back()
            ->with('success', 'Room assigned successfully.');
    }
}
