<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Room;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function index(Request $request)
    {
        $query = Room::with('building');

        if ($request->filled('building')) {
            $query->byBuilding($request->building);
        }

        if ($request->filled('floor')) {
            $query->byFloor($request->floor);
        }

        if ($request->filled('type')) {
            $query->byType($request->type);
        }

        if ($request->filled('status')) {
            $query->byStatus($request->status);
        }

        $rooms = $query->get();

        return response()->json([
            'rooms' => $rooms->map(function($room) {
                return [
                    'id' => $room->id,
                    'room_number' => $room->room_number,
                    'building' => $room->building->name ?? null,
                    'floor' => $room->floor,
                    'type' => $room->type,
                    'capacity' => $room->capacity,
                    'current_occupancy' => $room->current_occupancy,
                    'available_beds' => $room->availableBeds(),
                    'status' => $room->status,
                    'price' => $room->price,
                    'amenities' => $room->amenities,
                ];
            }),
        ]);
    }

    public function available()
    {
        $rooms = Room::with('building')
            ->available()
            ->whereColumn('current_occupancy', '<', 'capacity')
            ->get();

        return response()->json([
            'rooms' => $rooms->map(function($room) {
                return [
                    'id' => $room->id,
                    'room_number' => $room->room_number,
                    'building' => $room->building->name ?? null,
                    'floor' => $room->floor,
                    'type' => $room->type,
                    'capacity' => $room->capacity,
                    'current_occupancy' => $room->current_occupancy,
                    'available_beds' => $room->availableBeds(),
                    'price' => $room->price,
                    'amenities' => $room->amenities,
                ];
            }),
        ]);
    }

    public function show(Room $room)
    {
        $room->load('building');

        return response()->json([
            'room' => [
                'id' => $room->id,
                'room_number' => $room->room_number,
                'building' => $room->building->name ?? null,
                'floor' => $room->floor,
                'type' => $room->type,
                'capacity' => $room->capacity,
                'current_occupancy' => $room->current_occupancy,
                'available_beds' => $room->availableBeds(),
                'status' => $room->status,
                'price' => $room->price,
                'description' => $room->description,
                'amenities' => $room->amenities,
            ],
        ]);
    }

    public function myRoom(Request $request)
    {
        $user = $request->user();
        $user->load('room.building');

        if (!$user->room) {
            return response()->json([
                'message' => 'You do not have an assigned room.',
            ], 404);
        }

        return response()->json([
            'room' => [
                'id' => $user->room->id,
                'room_number' => $user->room->room_number,
                'building' => $user->room->building->name ?? null,
                'floor' => $user->room->floor,
                'type' => $user->room->type,
                'price' => $user->room->price,
                'description' => $user->room->description,
                'amenities' => $user->room->amenities,
            ],
        ]);
    }
}
