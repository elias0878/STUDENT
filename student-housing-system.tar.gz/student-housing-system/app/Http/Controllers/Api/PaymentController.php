<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function index(Request $request)
    {
        $payments = Payment::where('user_id', $request->user()->id)
            ->latest()
            ->get();

        return response()->json([
            'payments' => $payments->map(function($payment) {
                return [
                    'id' => $payment->id,
                    'amount' => $payment->amount,
                    'payment_type' => $payment->payment_type,
                    'payment_method' => $payment->payment_method,
                    'payment_date' => $payment->payment_date ? $payment->payment_date->format('Y-m-d') : null,
                    'due_date' => $payment->due_date->format('Y-m-d'),
                    'status' => $payment->status,
                    'transaction_id' => $payment->transaction_id,
                    'notes' => $payment->notes,
                ];
            }),
        ]);
    }

    public function show(Request $request, Payment $payment)
    {
        if ($payment->user_id !== $request->user()->id) {
            return response()->json([
                'message' => 'Unauthorized.',
            ], 403);
        }

        return response()->json([
            'payment' => [
                'id' => $payment->id,
                'amount' => $payment->amount,
                'payment_type' => $payment->payment_type,
                'payment_method' => $payment->payment_method,
                'payment_date' => $payment->payment_date ? $payment->payment_date->format('Y-m-d') : null,
                'due_date' => $payment->due_date->format('Y-m-d'),
                'status' => $payment->status,
                'transaction_id' => $payment->transaction_id,
                'notes' => $payment->notes,
            ],
        ]);
    }

    public function pending(Request $request)
    {
        $payments = Payment::where('user_id', $request->user()->id)
            ->where('status', 'pending')
            ->latest()
            ->get();

        return response()->json([
            'payments' => $payments->map(function($payment) {
                return [
                    'id' => $payment->id,
                    'amount' => $payment->amount,
                    'payment_type' => $payment->payment_type,
                    'due_date' => $payment->due_date->format('Y-m-d'),
                    'status' => $payment->status,
                ];
            }),
        ]);
    }

    public function history(Request $request)
    {
        $payments = Payment::where('user_id', $request->user()->id)
            ->where('status', 'paid')
            ->latest()
            ->get();

        return response()->json([
            'payments' => $payments->map(function($payment) {
                return [
                    'id' => $payment->id,
                    'amount' => $payment->amount,
                    'payment_type' => $payment->payment_type,
                    'payment_method' => $payment->payment_method,
                    'payment_date' => $payment->payment_date ? $payment->payment_date->format('Y-m-d') : null,
                    'transaction_id' => $payment->transaction_id,
                ];
            }),
        ]);
    }
}
