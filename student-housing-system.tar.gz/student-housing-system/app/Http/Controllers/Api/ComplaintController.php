<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use Illuminate\Http\Request;

class ComplaintController extends Controller
{
    public function index(Request $request)
    {
        $complaints = Complaint::where('user_id', $request->user()->id)
            ->latest()
            ->get();

        return response()->json([
            'complaints' => $complaints->map(function($complaint) {
                return [
                    'id' => $complaint->id,
                    'title' => $complaint->title,
                    'description' => $complaint->description,
                    'type' => $complaint->type,
                    'status' => $complaint->status,
                    'priority' => $complaint->priority,
                    'created_at' => $complaint->created_at->format('Y-m-d H:i:s'),
                ];
            }),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'type' => 'required|in:maintenance,cleaning,electrical,plumbing,furniture,other',
            'priority' => 'required|in:low,medium,high,urgent',
        ]);

        $validated['user_id'] = $request->user()->id;
        $validated['status'] = 'pending';

        $complaint = Complaint::create($validated);

        return response()->json([
            'message' => 'Complaint submitted successfully.',
            'complaint' => [
                'id' => $complaint->id,
                'title' => $complaint->title,
                'status' => $complaint->status,
                'created_at' => $complaint->created_at->format('Y-m-d H:i:s'),
            ],
        ], 201);
    }

    public function show(Request $request, Complaint $complaint)
    {
        if ($complaint->user_id !== $request->user()->id) {
            return response()->json([
                'message' => 'Unauthorized.',
            ], 403);
        }

        return response()->json([
            'complaint' => [
                'id' => $complaint->id,
                'title' => $complaint->title,
                'description' => $complaint->description,
                'type' => $complaint->type,
                'status' => $complaint->status,
                'priority' => $complaint->priority,
                'resolution_notes' => $complaint->resolution_notes,
                'created_at' => $complaint->created_at->format('Y-m-d H:i:s'),
                'resolved_at' => $complaint->resolved_at ? $complaint->resolved_at->format('Y-m-d H:i:s') : null,
            ],
        ]);
    }
}
