<?php

namespace App\Http\Controllers;

use App\Models\Building;
use App\Models\Room;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function index(Request $request)
    {
        $query = Room::with('building');

        if ($request->filled('building')) {
            $query->byBuilding($request->building);
        }

        if ($request->filled('floor')) {
            $query->byFloor($request->floor);
        }

        if ($request->filled('type')) {
            $query->byType($request->type);
        }

        if ($request->filled('status')) {
            $query->byStatus($request->status);
        }

        $rooms = $query->latest()->paginate(20);
        $buildings = Building::where('is_active', true)->get();

        return view('rooms.index', compact('rooms', 'buildings'));
    }

    public function create()
    {
        $buildings = Building::where('is_active', true)->get();
        return view('rooms.create', compact('buildings'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'building_id' => 'required|exists:buildings,id',
            'room_number' => 'required|string|max:50',
            'floor' => 'required|integer|min:1',
            'type' => 'required|in:single,double,triple,quad',
            'capacity' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'amenities' => 'nullable|array',
        ]);

        $validated['amenities'] = $request->input('amenities', []);

        Room::create($validated);

        return redirect()->route('rooms.index')
            ->with('success', 'Room created successfully.');
    }

    public function show(Room $room)
    {
        $room->load(['building', 'students']);
        return view('rooms.show', compact('room'));
    }

    public function edit(Room $room)
    {
        $buildings = Building::where('is_active', true)->get();
        return view('rooms.edit', compact('room', 'buildings'));
    }

    public function update(Request $request, Room $room)
    {
        $validated = $request->validate([
            'building_id' => 'required|exists:buildings,id',
            'room_number' => 'required|string|max:50',
            'floor' => 'required|integer|min:1',
            'type' => 'required|in:single,double,triple,quad',
            'capacity' => 'required|integer|min:1',
            'status' => 'required|in:available,occupied,maintenance',
            'price' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'amenities' => 'nullable|array',
        ]);

        $validated['amenities'] = $request->input('amenities', []);

        $room->update($validated);

        return redirect()->route('rooms.index')
            ->with('success', 'Room updated successfully.');
    }

    public function destroy(Room $room)
    {
        if ($room->students()->count() > 0) {
            return redirect()->route('rooms.index')
                ->with('error', 'Cannot delete room with students.');
        }

        $room->delete();

        return redirect()->route('rooms.index')
            ->with('success', 'Room deleted successfully.');
    }

    public function availableRooms()
    {
        $rooms = Room::with('building')
            ->available()
            ->whereColumn('current_occupancy', '<', 'capacity')
            ->get();

        return view('rooms.available', compact('rooms'));
    }
}
