<?php

namespace App\Http\Controllers;

use App\Models\Building;
use App\Models\HousingApplication;
use App\Models\Room;
use App\Models\User;
use App\Notifications\HousingApplicationStatusChanged;
use Illuminate\Http\Request;

class HousingApplicationController extends Controller
{
    public function index(Request $request)
    {
        $query = HousingApplication::with(['user', 'preferredBuilding']);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('academic_year')) {
            $query->where('academic_year', $request->academic_year);
        }

        $applications = $query->latest()->paginate(20);

        return view('applications.index', compact('applications'));
    }

    public function create()
    {
        $buildings = Building::where('is_active', true)->get();
        return view('applications.create', compact('buildings'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'preferred_building_id' => 'nullable|exists:buildings,id',
            'preferred_room_type' => 'nullable|in:single,double,triple,quad',
            'academic_year' => 'required|string',
            'semester' => 'required|in:first,second,summer',
        ]);

        $existingApplication = HousingApplication::where('user_id', auth()->id())
            ->where('academic_year', $validated['academic_year'])
            ->where('semester', $validated['semester'])
            ->whereIn('status', ['pending', 'approved'])
            ->first();

        if ($existingApplication) {
            return redirect()->back()
                ->with('error', 'You already have an application for this academic period.');
        }

        $validated['user_id'] = auth()->id();
        $validated['status'] = 'pending';
        $validated['application_date'] = now();

        $application = HousingApplication::create($validated);

        return redirect()->route('applications.my')
            ->with('success', 'Housing application submitted successfully.');
    }

    public function show(HousingApplication $application)
    {
        $application->load(['user', 'preferredBuilding', 'processedBy']);
        $availableRooms = Room::available()
            ->whereColumn('current_occupancy', '<', 'capacity')
            ->get();

        return view('applications.show', compact('application', 'availableRooms'));
    }

    public function approve(Request $request, HousingApplication $application)
    {
        $validated = $request->validate([
            'room_id' => 'required|exists:rooms,id',
        ]);

        $room = Room::find($validated['room_id']);

        if (!$room->isAvailable()) {
            return redirect()->back()
                ->with('error', 'Selected room is not available.');
        }

        $application->approve(auth()->id());

        $student = $application->user;
        $student->update(['room_id' => $room->id]);

        $room->increment('current_occupancy');
        if ($room->isFull()) {
            $room->update(['status' => 'occupied']);
        }

        $student->notify(new HousingApplicationStatusChanged($application, 'approved'));

        return redirect()->route('applications.index')
            ->with('success', 'Application approved successfully.');
    }

    public function reject(Request $request, HousingApplication $application)
    {
        $validated = $request->validate([
            'notes' => 'nullable|string',
        ]);

        $application->reject(auth()->id(), $validated['notes']);

        $application->user->notify(new HousingApplicationStatusChanged($application, 'rejected'));

        return redirect()->route('applications.index')
            ->with('success', 'Application rejected successfully.');
    }

    public function myApplications()
    {
        $applications = HousingApplication::where('user_id', auth()->id())
            ->latest()
            ->paginate(20);

        return view('applications.my', compact('applications'));
    }

    public function destroy(HousingApplication $application)
    {
        if ($application->status === 'approved') {
            return redirect()->back()
                ->with('error', 'Cannot delete approved application.');
        }

        $application->delete();

        return redirect()->route('applications.my')
            ->with('success', 'Application cancelled successfully.');
    }
}
