<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use App\Models\User;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function index(Request $request)
    {
        $query = Payment::with('user');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('type')) {
            $query->where('payment_type', $request->type);
        }

        if ($request->filled('student')) {
            $query->where('user_id', $request->student);
        }

        $payments = $query->latest()->paginate(20);
        $students = User::role('student')->get();

        return view('payments.index', compact('payments', 'students'));
    }

    public function create()
    {
        $students = User::role('student')->get();
        return view('payments.create', compact('students'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'amount' => 'required|numeric|min:0',
            'payment_type' => 'required|in:rent,deposit,service,fine,other',
            'payment_method' => 'required|in:cash,bank_transfer,credit_card,online',
            'due_date' => 'required|date',
            'notes' => 'nullable|string',
        ]);

        $validated['status'] = 'pending';

        Payment::create($validated);

        return redirect()->route('payments.index')
            ->with('success', 'Payment record created successfully.');
    }

    public function show(Payment $payment)
    {
        $payment->load(['user', 'receivedBy']);
        return view('payments.show', compact('payment'));
    }

    public function edit(Payment $payment)
    {
        $students = User::role('student')->get();
        return view('payments.edit', compact('payment', 'students'));
    }

    public function update(Request $request, Payment $payment)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'amount' => 'required|numeric|min:0',
            'payment_type' => 'required|in:rent,deposit,service,fine,other',
            'payment_method' => 'nullable|in:cash,bank_transfer,credit_card,online',
            'payment_date' => 'nullable|date',
            'due_date' => 'required|date',
            'status' => 'required|in:paid,pending,overdue,cancelled',
            'notes' => 'nullable|string',
        ]);

        $payment->update($validated);

        return redirect()->route('payments.index')
            ->with('success', 'Payment updated successfully.');
    }

    public function destroy(Payment $payment)
    {
        $payment->delete();

        return redirect()->route('payments.index')
            ->with('success', 'Payment deleted successfully.');
    }

    public function recordPayment(Request $request, Payment $payment)
    {
        $validated = $request->validate([
            'payment_method' => 'required|in:cash,bank_transfer,credit_card,online',
            'transaction_id' => 'nullable|string',
        ]);

        $payment->markAsPaid($validated['payment_method'], $validated['transaction_id']);
        $payment->update(['received_by' => auth()->id()]);

        return redirect()->back()
            ->with('success', 'Payment recorded successfully.');
    }

    public function myPayments()
    {
        $payments = Payment::where('user_id', auth()->id())
            ->latest()
            ->paginate(20);

        return view('payments.my', compact('payments'));
    }

    public function overdue()
    {
        $payments = Payment::overdue()
            ->with('user')
            ->latest()
            ->paginate(20);

        return view('payments.overdue', compact('payments'));
    }
}
