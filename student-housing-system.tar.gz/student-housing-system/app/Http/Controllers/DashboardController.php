<?php

namespace App\Http\Controllers;

use App\Models\Building;
use App\Models\Complaint;
use App\Models\Payment;
use App\Models\Room;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_students' => User::role('student')->count(),
            'active_students' => User::role('student')->where('is_active', true)->count(),
            'total_rooms' => Room::count(),
            'available_rooms' => Room::where('status', 'available')->count(),
            'occupied_rooms' => Room::where('status', 'occupied')->count(),
            'maintenance_rooms' => Room::where('status', 'maintenance')->count(),
            'total_buildings' => Building::where('is_active', true)->count(),
            'pending_complaints' => Complaint::where('status', 'pending')->count(),
            'total_complaints' => Complaint::count(),
            'monthly_payments' => Payment::whereMonth('payment_date', Carbon::now()->month)
                                        ->whereYear('payment_date', Carbon::now()->year)
                                        ->sum('amount'),
            'pending_payments' => Payment::where('status', 'pending')->count(),
            'overdue_payments' => Payment::overdue()->count(),
        ];

        $occupancyRate = $stats['total_rooms'] > 0 
            ? round(($stats['occupied_rooms'] / $stats['total_rooms']) * 100, 2) 
            : 0;

        $complaintsByType = Complaint::select('type', DB::raw('count(*) as count'))
            ->groupBy('type')
            ->orderByDesc('count')
            ->get();

        $monthlyOccupancy = $this->getMonthlyOccupancyStats();
        $monthlyPayments = $this->getMonthlyPaymentsStats();

        $recentComplaints = Complaint::with('user')
            ->latest()
            ->take(5)
            ->get();

        $recentPayments = Payment::with('user')
            ->where('status', 'paid')
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard', compact(
            'stats',
            'occupancyRate',
            'complaintsByType',
            'monthlyOccupancy',
            'monthlyPayments',
            'recentComplaints',
            'recentPayments'
        ));
    }

    private function getMonthlyOccupancyStats()
    {
        $stats = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = Carbon::now()->subMonths($i);
            $totalRooms = Room::count();
            $occupiedRooms = Room::where('status', 'occupied')
                ->whereMonth('updated_at', $month->month)
                ->whereYear('updated_at', $month->year)
                ->count();
            
            $stats[] = [
                'month' => $month->format('M Y'),
                'rate' => $totalRooms > 0 ? round(($occupiedRooms / $totalRooms) * 100, 2) : 0,
            ];
        }
        return $stats;
    }

    private function getMonthlyPaymentsStats()
    {
        $stats = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = Carbon::now()->subMonths($i);
            $amount = Payment::whereMonth('payment_date', $month->month)
                ->whereYear('payment_date', $month->year)
                ->sum('amount');
            
            $stats[] = [
                'month' => $month->format('M Y'),
                'amount' => $amount,
            ];
        }
        return $stats;
    }
}
