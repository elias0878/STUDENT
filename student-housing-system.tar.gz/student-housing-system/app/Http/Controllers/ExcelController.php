<?php

namespace App\Http\Controllers;

use App\Exports\PaymentsExport;
use App\Exports\ResidentsExport;
use App\Exports\RoomsExport;
use App\Imports\RoomsImport;
use App\Imports\StudentsImport;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class ExcelController extends Controller
{
    public function importStudents(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        Excel::import(new StudentsImport, $request->file('file'));

        return redirect()->back()
            ->with('success', 'Students imported successfully.');
    }

    public function importRooms(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        Excel::import(new RoomsImport, $request->file('file'));

        return redirect()->back()
            ->with('success', 'Rooms imported successfully.');
    }

    public function exportResidents()
    {
        return Excel::download(new ResidentsExport, 'residents_' . now()->format('Y-m-d') . '.xlsx');
    }

    public function exportPayments(Request $request)
    {
        $month = $request->input('month', now()->month);
        $year = $request->input('year', now()->year);

        return Excel::download(
            new PaymentsExport($month, $year), 
            'payments_' . $year . '_' . $month . '.xlsx'
        );
    }

    public function exportAvailableRooms()
    {
        return Excel::download(new RoomsExport, 'available_rooms_' . now()->format('Y-m-d') . '.xlsx');
    }

    public function showImportForm()
    {
        return view('excel.import');
    }

    public function showExportForm()
    {
        return view('excel.export');
    }
}
