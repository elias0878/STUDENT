<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        //
    ];

    public function boot(): void
    {
        $this->registerPolicies();

        // Define Gates
        Gate::define('manage-buildings', function ($user) {
            return $user->isAdmin();
        });

        Gate::define('manage-rooms', function ($user) {
            return $user->isAdmin() || $user->isSupervisor();
        });

        Gate::define('manage-students', function ($user) {
            return $user->isAdmin() || $user->isSupervisor();
        });

        Gate::define('manage-payments', function ($user) {
            return $user->isAdmin() || $user->isAccountant();
        });

        Gate::define('send-complaint', function ($user) {
            return $user->isStudent();
        });

        Gate::define('manage-users', function ($user) {
            return $user->isAdmin();
        });
    }
}
