<?php

namespace App\Notifications;

use App\Models\HousingApplication;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class HousingApplicationStatusChanged extends Notification
{
    use Queueable;

    protected $application;
    protected $status;

    public function __construct(HousingApplication $application, string $status)
    {
        $this->application = $application;
        $this->status = $status;
    }

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $subject = $this->status === 'approved' 
            ? 'Your Housing Application has been Approved!' 
            : 'Update on Your Housing Application';

        $message = $this->status === 'approved'
            ? 'Congratulations! Your housing application for ' . $this->application->academic_year . ' has been approved.'
            : 'We regret to inform you that your housing application for ' . $this->application->academic_year . ' has been rejected.';

        return (new MailMessage)
            ->subject($subject)
            ->line($message)
            ->line('Academic Year: ' . $this->application->academic_year)
            ->line('Semester: ' . ucfirst($this->application->semester))
            ->when($this->status === 'rejected', function($mail) {
                return $mail->line('Reason: ' . ($this->application->notes ?? 'No reason provided'));
            })
            ->action('View Application', url('/applications/my'))
            ->line('Thank you for using our housing system!');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'application_id' => $this->application->id,
            'status' => $this->status,
            'academic_year' => $this->application->academic_year,
            'semester' => $this->application->semester,
            'message' => $this->status === 'approved' 
                ? 'Your housing application has been approved!' 
                : 'Your housing application has been rejected.',
        ];
    }
}
