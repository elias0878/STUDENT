<?php

namespace App\Notifications;

use App\Models\Payment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class PaymentReminderNotification extends Notification
{
    use Queueable;

    protected $payment;

    public function __construct(Payment $payment)
    {
        $this->payment = $payment;
    }

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Payment Reminder - Overdue Payment')
            ->line('This is a reminder that you have an overdue payment.')
            ->line('Payment Type: ' . ucfirst($this->payment->payment_type))
            ->line('Amount: $' . number_format($this->payment->amount, 2))
            ->line('Due Date: ' . $this->payment->due_date->format('Y-m-d'))
            ->line('Please make the payment as soon as possible to avoid any penalties.')
            ->action('View Payment Details', url('/payments/my'))
            ->line('Thank you!');
    }

    public function toArray(object $notifiable): array
    {
        return [
            'payment_id' => $this->payment->id,
            'amount' => $this->payment->amount,
            'payment_type' => $this->payment->payment_type,
            'due_date' => $this->payment->due_date->format('Y-m-d'),
            'message' => 'You have an overdue payment of $' . number_format($this->payment->amount, 2),
        ];
    }
}
