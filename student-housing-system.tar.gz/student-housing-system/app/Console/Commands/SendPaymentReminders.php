<?php

namespace App\Console\Commands;

use App\Models\Payment;
use App\Notifications\PaymentReminderNotification;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SendPaymentReminders extends Command
{
    protected $signature = 'payments:send-reminders';
    protected $description = 'Send payment reminders for overdue payments';

    public function handle()
    {
        $this->info('Checking for overdue payments...');

        $overduePayments = Payment::overdue()
            ->with('user')
            ->whereNull('reminder_sent_at')
            ->orWhere('reminder_sent_at', '<', now()->subDays(7))
            ->get();

        $count = 0;

        foreach ($overduePayments as $payment) {
            try {
                $payment->user->notify(new PaymentReminderNotification($payment));
                
                $payment->update(['reminder_sent_at' => now()]);

                Log::info('Payment reminder sent', [
                    'payment_id' => $payment->id,
                    'user_id' => $payment->user_id,
                    'amount' => $payment->amount,
                    'due_date' => $payment->due_date->format('Y-m-d'),
                ]);

                $count++;
                $this->info("Reminder sent to {$payment->user->name} for payment #{$payment->id}");
            } catch (\Exception $e) {
                Log::error('Failed to send payment reminder', [
                    'payment_id' => $payment->id,
                    'error' => $e->getMessage(),
                ]);

                $this->error("Failed to send reminder for payment #{$payment->id}");
            }
        }

        $this->info("Sent {$count} payment reminders.");
        $this->info('Payment reminder process completed.');

        return Command::SUCCESS;
    }
}
