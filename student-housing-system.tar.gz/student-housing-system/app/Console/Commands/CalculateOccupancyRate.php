<?php

namespace App\Console\Commands;

use App\Models\Building;
use App\Models\Room;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CalculateOccupancyRate extends Command
{
    protected $signature = 'occupancy:calculate';
    protected $description = 'Calculate daily occupancy rate for all buildings';

    public function handle()
    {
        $this->info('Calculating occupancy rates...');

        $totalRooms = Room::count();
        $occupiedRooms = Room::where('status', 'occupied')->count();
        $availableRooms = Room::where('status', 'available')->count();
        $maintenanceRooms = Room::where('status', 'maintenance')->count();

        $overallRate = $totalRooms > 0 ? round(($occupiedRooms / $totalRooms) * 100, 2) : 0;

        Log::info('Daily Occupancy Report', [
            'date' => now()->format('Y-m-d'),
            'total_rooms' => $totalRooms,
            'occupied_rooms' => $occupiedRooms,
            'available_rooms' => $availableRooms,
            'maintenance_rooms' => $maintenanceRooms,
            'occupancy_rate' => $overallRate . '%',
        ]);

        $buildings = Building::withCount('rooms')->get();

        foreach ($buildings as $building) {
            $buildingTotal = $building->rooms_count;
            $buildingOccupied = $building->rooms()->where('status', 'occupied')->count();
            $buildingRate = $buildingTotal > 0 ? round(($buildingOccupied / $buildingTotal) * 100, 2) : 0;

            Log::info("Building: {$building->name}", [
                'total_rooms' => $buildingTotal,
                'occupied_rooms' => $buildingOccupied,
                'occupancy_rate' => $buildingRate . '%',
            ]);

            $this->info("{$building->name}: {$buildingRate}% occupancy");
        }

        $this->info("Overall occupancy rate: {$overallRate}%");
        $this->info('Occupancy calculation completed.');

        return Command::SUCCESS;
    }
}
