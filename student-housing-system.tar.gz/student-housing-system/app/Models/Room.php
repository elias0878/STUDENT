<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    use HasFactory;

    protected $fillable = [
        'building_id',
        'room_number',
        'floor',
        'type',
        'capacity',
        'current_occupancy',
        'status',
        'price',
        'description',
        'amenities',
    ];

    protected $casts = [
        'floor' => 'integer',
        'capacity' => 'integer',
        'current_occupancy' => 'integer',
        'price' => 'decimal:2',
        'amenities' => 'array',
    ];

    const STATUS_AVAILABLE = 'available';
    const STATUS_OCCUPIED = 'occupied';
    const STATUS_MAINTENANCE = 'maintenance';

    const TYPE_SINGLE = 'single';
    const TYPE_DOUBLE = 'double';
    const TYPE_TRIPLE = 'triple';
    const TYPE_QUAD = 'quad';

    public function building()
    {
        return $this->belongsTo(Building::class);
    }

    public function students()
    {
        return $this->hasMany(User::class);
    }

    public function isAvailable()
    {
        return $this->status === self::STATUS_AVAILABLE && $this->current_occupancy < $this->capacity;
    }

    public function isFull()
    {
        return $this->current_occupancy >= $this->capacity;
    }

    public function availableBeds()
    {
        return $this->capacity - $this->current_occupancy;
    }

    public function scopeAvailable($query)
    {
        return $query->where('status', self::STATUS_AVAILABLE);
    }

    public function scopeByBuilding($query, $buildingId)
    {
        return $query->where('building_id', $buildingId);
    }

    public function scopeByFloor($query, $floor)
    {
        return $query->where('floor', $floor);
    }

    public function scopeByType($query, $type)
    {
        return $query->where('type', $type);
    }

    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }
}
