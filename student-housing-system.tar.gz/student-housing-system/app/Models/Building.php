<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Building extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'code',
        'address',
        'floors_count',
        'rooms_count',
        'description',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'floors_count' => 'integer',
        'rooms_count' => 'integer',
    ];

    public function rooms()
    {
        return $this->hasMany(Room::class);
    }

    public function getOccupancyRateAttribute()
    {
        $totalRooms = $this->rooms()->count();
        if ($totalRooms === 0) return 0;
        
        $occupiedRooms = $this->rooms()->where('status', 'occupied')->count();
        return round(($occupiedRooms / $totalRooms) * 100, 2);
    }
}
