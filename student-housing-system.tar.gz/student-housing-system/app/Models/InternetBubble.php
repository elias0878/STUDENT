<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InternetBubble extends Model
{
    use HasFactory;

    protected $table = 'internet_bubbles';

    protected $fillable = [
        'name',
        'code',
        'speed',
        'data_limit',
        'duration_days',
        'price',
        'description',
        'is_active',
    ];

    protected $casts = [
        'speed' => 'integer',
        'data_limit' => 'integer',
        'duration_days' => 'integer',
        'price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function users()
    {
        return $this->belongsToMany(User::class, 'internet_bubble_user')
                    ->withPivot('activation_date', 'expiry_date', 'status', 'data_used')
                    ->withTimestamps();
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
