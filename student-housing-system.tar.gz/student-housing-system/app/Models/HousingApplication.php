<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HousingApplication extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'preferred_building_id',
        'preferred_room_type',
        'academic_year',
        'semester',
        'status',
        'application_date',
        'processed_at',
        'processed_by',
        'notes',
    ];

    protected $casts = [
        'application_date' => 'datetime',
        'processed_at' => 'datetime',
    ];

    const STATUS_PENDING = 'pending';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    const STATUS_WAITLIST = 'waitlist';

    const SEMESTER_FIRST = 'first';
    const SEMESTER_SECOND = 'second';
    const SEMESTER_SUMMER = 'summer';

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function preferredBuilding()
    {
        return $this->belongsTo(Building::class, 'preferred_building_id');
    }

    public function processedBy()
    {
        return $this->belongsTo(User::class, 'processed_by');
    }

    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    public function isPending()
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function approve($processedBy = null)
    {
        $this->update([
            'status' => self::STATUS_APPROVED,
            'processed_at' => now(),
            'processed_by' => $processedBy,
        ]);
    }

    public function reject($processedBy = null, $notes = null)
    {
        $this->update([
            'status' => self::STATUS_REJECTED,
            'processed_at' => now(),
            'processed_by' => $processedBy,
            'notes' => $notes,
        ]);
    }
}
