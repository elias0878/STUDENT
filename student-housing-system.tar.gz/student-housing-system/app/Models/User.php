<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'student_id',
        'avatar',
        'is_active',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'is_active' => 'boolean',
    ];

    public function room()
    {
        return $this->belongsTo(Room::class);
    }

    public function complaints()
    {
        return $this->hasMany(Complaint::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function services()
    {
        return $this->belongsToMany(Service::class, 'service_user')
                    ->withPivot('scheduled_date', 'status', 'notes')
                    ->withTimestamps();
    }

    public function internetBubbles()
    {
        return $this->belongsToMany(InternetBubble::class, 'internet_bubble_user')
                    ->withPivot('activation_date', 'expiry_date', 'status')
                    ->withTimestamps();
    }

    public function isAdmin()
    {
        return $this->hasRole('admin');
    }

    public function isSupervisor()
    {
        return $this->hasRole('supervisor');
    }

    public function isAccountant()
    {
        return $this->hasRole('accountant');
    }

    public function isStudent()
    {
        return $this->hasRole('student');
    }
}
