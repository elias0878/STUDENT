<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'type',
        'price',
        'is_active',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    const TYPE_CLEANING = 'cleaning';
    const TYPE_MAINTENANCE = 'maintenance';
    const TYPE_LAUNDRY = 'laundry';
    const TYPE_TRANSPORT = 'transport';
    const TYPE_OTHER = 'other';

    public function users()
    {
        return $this->belongsToMany(User::class, 'service_user')
                    ->withPivot('scheduled_date', 'status', 'notes')
                    ->withTimestamps();
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeByType($query, $type)
    {
        return $query->where('type', $type);
    }
}
