<?php

namespace App\Exports;

use App\Models\Payment;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class PaymentsExport implements FromCollection, WithHeadings, WithMapping
{
    protected $month;
    protected $year;

    public function __construct($month, $year)
    {
        $this->month = $month;
        $this->year = $year;
    }

    public function collection()
    {
        return Payment::with('user')
            ->whereMonth('payment_date', $this->month)
            ->whereYear('payment_date', $this->year)
            ->get();
    }

    public function headings(): array
    {
        return [
            'Payment ID',
            'Student Name',
            'Student ID',
            'Amount',
            'Payment Type',
            'Payment Method',
            'Payment Date',
            'Due Date',
            'Status',
            'Transaction ID',
            'Notes',
        ];
    }

    public function map($payment): array
    {
        return [
            $payment->id,
            $payment->user->name ?? 'N/A',
            $payment->user->student_id ?? 'N/A',
            $payment->amount,
            $payment->payment_type,
            $payment->payment_method ?? 'N/A',
            $payment->payment_date ? $payment->payment_date->format('Y-m-d') : 'N/A',
            $payment->due_date->format('Y-m-d'),
            $payment->status,
            $payment->transaction_id ?? 'N/A',
            $payment->notes ?? 'N/A',
        ];
    }
}
