<?php

namespace App\Exports;

use App\Models\Room;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class RoomsExport implements FromCollection, WithHeadings, WithMapping
{
    public function collection()
    {
        return Room::with('building')
            ->where('status', 'available')
            ->whereColumn('current_occupancy', '<', 'capacity')
            ->get();
    }

    public function headings(): array
    {
        return [
            'Room ID',
            'Building',
            'Room Number',
            'Floor',
            'Type',
            'Capacity',
            'Current Occupancy',
            'Available Beds',
            'Price',
            'Status',
            'Description',
        ];
    }

    public function map($room): array
    {
        return [
            $room->id,
            $room->building->name ?? 'N/A',
            $room->room_number,
            $room->floor,
            $room->type,
            $room->capacity,
            $room->current_occupancy,
            $room->availableBeds(),
            $room->price,
            $room->status,
            $room->description ?? 'N/A',
        ];
    }
}
