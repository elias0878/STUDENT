<?php

namespace App\Exports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ResidentsExport implements FromCollection, WithHeadings, WithMapping
{
    public function collection()
    {
        return User::role('student')
            ->with('room.building')
            ->get();
    }

    public function headings(): array
    {
        return [
            'Student ID',
            'Name',
            'Email',
            'Phone',
            'Building',
            'Room Number',
            'Floor',
            'Room Type',
            'Status',
            'Joined Date',
        ];
    }

    public function map($student): array
    {
        return [
            $student->student_id,
            $student->name,
            $student->email,
            $student->phone,
            $student->room->building->name ?? 'N/A',
            $student->room->room_number ?? 'N/A',
            $student->room->floor ?? 'N/A',
            $student->room->type ?? 'N/A',
            $student->is_active ? 'Active' : 'Inactive',
            $student->created_at->format('Y-m-d'),
        ];
    }
}
